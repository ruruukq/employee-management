<?php 
include 'dbconnection.php';

if(isset($_GET["empid"])){
    $empid = $_GET['empid'];

    $sql = "SELECT * FROM register WHERE empid = '$empid'";
    $result = $conn->query($sql);

    if (!$result) {
        die("Error executing the query: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fname = $row['fname'];
    } else {
        echo "No matching record found for id: $empid";
    }
    $sql_leave = "SELECT * FROM leave_notice WHERE empid = '$empid' ORDER BY 
    CASE
        WHEN apprv = 'PENDING' THEN 1
        ELSE 2
    END, id DESC";
    $leave_result = $conn->query($sql_leave); 

    if (!$leave_result) {
        die("Error executing the query: " . $conn->error);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png">  
    <link rel="stylesheet" href="css/view.css">
    <title><?php echo $fname; ?></title>
    <style>
        .table-responsive {
            overflow-x: auto;
        }
th:nth-child(1),
td:nth-child(1) {
    width: 150px;
}

    </style>
</head>
<body>
<?php
include_once 'user_sidebar.php';
?>
 <div class="main--content">
      <div class="header--wrapper">
        <div class="header--title">
        <h4 style=" font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;">&nbsp;&nbsp;LEAVE REQUESTS</h4>
</div>
    
  </div>
<!---------------------------------------ADD--------------------------------------------------->
  <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header" style="background: #137d74; color: #fff;">
        <h1 class="modal-title fs-5" id="exampleModalLabel" style="font-family: 'verdana';">REQUEST LEAVE</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="user_leavef.php" method="POST">
      <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
      <div class="col">
    <label>Employee's Full Name</label>
    <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $row['fname']; ?>" style="font-size: 12px;" readonly>
</div>

<div class="col">
    <label>Employee's ID</label>
    <input type="text" class="form-control" id="empid" name="empid" value="<?php echo $row['empid']; ?>" style="font-size: 12px;" readonly>
  </div>

  <div class="col">
    <label>Leave Type</label>
    <select class="form-control" id="ltype" name="ltype" style="font-size: 12px; font-family: 'Poppins';" required>
        <option value="" disabled selected>Leave Type</option>
        <option value="Sick Leave">Sick Leave</option>
        <option value="Annual Leave">Annual Leave</option>
        <option value="Medical Leave">Medical Leave</option>
        <option value="Paternity Leave">Paternity Leave</option>
        <option value="Maternity Leave">Maternity Leave</option>
        <option value="Vacation Leave">Vacation Leave</option>
        <option value="Religious Holidays">Religious Holidays</option>
    </select>
</div>


        <script>
  function validateForm() {
    var ltype = document.getElementById("ltype").value;
    if (ltype === "") {
      alert("Please select a leave type.");
      return false;
    }
    return true;
  }
</script>

<div class="col">
  <label>Reason</label>
  <br>
  <textarea class="form-control" name="msg" id="msg" rows="3" style="font-size: 12px;" required></textarea>
</div>

<br>

<div class="col">
  <label>Start Date :</label>
  <input type="date" class="form-control" name="fromd" id="fromd" style="font-size: 12px;" required>
</div>

<br>

<div class="col">
  <label>End Date :</label>
  <input type="date" class="form-control" name="tod" id="tod" style="font-size: 12px;" required>
</div>
<br>
      <div class="col">
        <label>Date Submitted :</label>
    <input class="form-control" value="<?php echo date('F j, Y');?>" readonly="readonly" style="font-size: 12px;" name="tdate">
        </div>
        </div>

      <div class="modal-footer">
      <input type="hidden" name="empid" value="<?php echo isset($row['empid']) ? $row['empid'] : ""; ?>">
        <button type="submit" class="btn btn-primary" id="back">Submit</button>
      </div>
    </div>
</form>
  </div>
</div>
<!------------------------------------------------------------------------------------->
<!---------------------------------ADD NOTIF------------------------------------------->
        <div class="row">
    <div class="col">
    <?php
    if(isset($_SESSION['status'])){
?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4><?php echo $_SESSION['status']; ?></h4>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['status']);
    }
?>
   <?php
    if(isset($_SESSION['istatus'])){
?>
<div class="alert alert-danger alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4><?php echo $_SESSION['istatus']; ?></h4>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['istatus']);
    }
?>
<!--------------------------------------------------------------------------------------->
    </div>
              <div class="col-lg-2">
              <button type="button" id="back" class="btn btn-primary form-control" data-bs-toggle="modal" data-bs-target="#addModal" href="user_leave.php?empid=<?php echo isset($row['empid']) ? $row['empid'] : ""; ?>">
Request Leave
</button>  
            </div>
    
<br>

<!----------------------------------------LEAVE TABLE------------------------------------>
<div class="table-responsive">
    <table class="table table-bordered">
        <br>
        <tr>
        <th>Leave Type</th>
            <th>Date Submitted</th>
            <th>Reason</th>
            <th style="text-align: center;">Start Date</th>
            <th style="text-align: center;">End Date</th>
            <th style="text-align: center;">Approval</th>
            <th style="text-align: center;">Action</th>
        </tr>
        <tbody>
            <?php 
            if(isset($leave_result) && $leave_result->num_rows > 0) {
                while ($row = $leave_result->fetch_assoc()) {
            ?>
                    <tr>
                    <td><?php echo $row['ltype']; ?></td>
                        <td><?php echo $row['tdate']; ?></td>
                        <td style="width: 300px;"><?php echo $row['msg']; ?><br></td>
                        <td style="text-align: center;"><?php echo date('F j, Y', strtotime($row['fromd'])); ?></td>
                        <td style="text-align: center;"><?php echo date('F j, Y', strtotime($row['tod'])); ?></td>
                        <td  style="text-align: center;" class="<?php echo getApprovalClass($row['apprv']); ?>"><?php echo $row['apprv']; ?></td>
                        <td style="text-align: center;">
                            <?php if(in_array($row['apprv'], ['REJECTED', 'CANCELED','APPROVED'])): ?>
                                <span class="text-muted">LEAVE <?php echo $row['apprv']; ?></span>
                                <?php else: ?>
                                <a href="user_leaveu.php?id=<?php echo isset($row['id']) ? $row['id'] : ""; ?>&empid=<?php echo isset($row['empid']) ? $row['empid'] : ""; ?>" class='btn' id="editButton">EDIT</a>
                            <button class='btn btn-danger btn-sm' id="btn" onclick="confirmCancel(<?php echo isset($row['id']) ? $row['id'] : ""; ?>, <?php echo isset($row['empid']) ? $row['empid'] : ""; ?>)">CANCEL</button>
                            <?php endif; ?>
                          </td>
                    </tr>
                <?php 
                }
            } else {
            ?>
                <tr>
                    <td colspan="6">No leave records found.</td>
                </tr>
            <?php 
            }
            ?>
        </tbody>
    </table>
</div>
<!------------------------------------------------------------------------------------------->
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
 <script>
    function confirmCancel(id, empid) {
        Swal.fire({
            title: 'Are you sure you want to cancel this leave?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#135D66',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, cancel it!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'user_cancel.php?cancel=' + id + '&empid=' + empid;
            }
        });
    }
</script>

<?php
function getApprovalClass($status) {
    switch ($status) {
        case 'APPROVED':
            return 'text-success';
        case 'REJECTED':
        case 'CANCELED':
            return 'text-danger';
        default:
            return 'text-primary';
}
}
?>

</body>
</html>
