<?php
include("dbconnection.php");

$name = $_POST['name'];

$current_date = date("F j, Y");

$sql = "SELECT DISTINCT fname, empid, datee, archived FROM `salary` WHERE fname LIKE '$name%' AND empid IS NOT NULL AND empid != '' AND archived = 'On Duty' GROUP BY fname ORDER BY `fname`";
$query = mysqli_query($conn, $sql);

if(mysqli_num_rows($query) > 0) {
    while($row = mysqli_fetch_assoc($query)) {
        echo "<tr>
                <td>".$row['fname']."</td>
                <td>".$row['empid']."</td>
                <td>".$row['datee']."</td>
            <td  style='text-align: center;'>
            <a href='salaryview.php?empid=".$row['empid']."' class='btn btn-primary btn-sm' id='btn'>VIEW</a>
            </td>
            </tr>";
    }
} else {
    echo "<tr><td colspan='8' style='text-align:center;'>No records found.</td></tr>";
}
?>