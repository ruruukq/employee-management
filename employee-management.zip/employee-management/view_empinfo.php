<?php 
include 'dbconnection.php';

if(isset($_GET["id"])){
    $id = $_GET['id'];

    $register_sql = "SELECT * FROM `register` WHERE `id` = '$id'";
    $register_result = $conn->query($register_sql);

    if (!$register_result) {
        die("Error executing the query: " . $conn->error);
    }

    if ($register_result->num_rows > 0) {

        $row = $register_result->fetch_assoc();
        $fname = $row['fname'];
        $empid = $row['empid'];
        $dept = $row['dept'];
        $contact = $row['contact'];
        $bdate = $row['bdate'];
        $mstats = $row['mstats'];
        $gender = $row['gender'];
        $addrss = $row['addrss'];
        $email = $row['email'];
        $scl = $row['scl']; 
        $deg = $row['deg']; 
        $skills = $row['skills']; 
        $cred = $row['cred'];
        $img = isset($row['img']) ? $row['img'] : '';
    } else {
 
        echo "No matching record found for id: $id";
    }

    $department_sql = "SELECT * FROM `department` WHERE `id` = '$id'";
    $department_result = $conn->query($department_sql);

    if (!$department_result) {
        die("Error executing the query: " . $conn->error);
    }

    if($department_result->num_rows > 0){ 

        $department_row = $department_result->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png">
    <link rel="stylesheet" href="css/edit.css">
    <title>ADMIN - <?php echo $fname; ?></title>
</head>
<body>


<!----------------------------------EDIT--------------------------------->

<div class="modal fade" id="eModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header" style="background: #137d74; color: #fff;">
        <h1 class="modal-title fs-5" id="exampleModalLabel">EDIT INFORMATION</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="editfunction.php" method="POST" enctype="multipart/form-data">
      <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
      <div>
  <input type="hidden" id="id" name="id" value="<?php echo $row['id']; ?>">
  
  <h4>Information :</h4>
    <div class="row">
      <div class="col">
        <label>Employee's Fullname</label> 
        <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $fname; ?>" placeholder="Enter Full Name" required="required" style="font-family: 'Poppins';">
      </div>

      <div class="col">
        <label>Employee's ID</label>
        <input type="number" class="form-control" id="empid" name="empid" value="<?php echo $empid; ?>" placeholder="Enter ID Number" required="required" style="font-family: 'Poppins';">
      </div>
      </div>

      <div class="row">
      <div class="col">
        <label>Birthdate</label>
        <input type="date" class="form-control" id="bdate" name="bdate" value="<?php echo $bdate; ?>" placeholder="Enter Birthday" required="required" style="font-family: 'Poppins';">
      </div>

      <div class="col">
    <label>Department</label>
    <select class="form-control" id="dept" name="dept" onchange="showSub(this.value)" style="font-family: 'Poppins';">
        <?php
        include 'dbconnection.php';
        $query = mysqli_query($conn, "SELECT * FROM department ORDER BY `dfull` ASC");
        while ($res = mysqli_fetch_array($query)) {
            $selected = ($res['dfull'] == $dept) ? 'selected' : '';
        ?>
            <option value="<?php echo htmlentities($res['dfull']); ?>" <?php echo $selected; ?>><?php echo htmlentities($res['dfull']) ?></option>
        <?php } ?>
    </select>
</div>
        </div>

        <div class="row">
        <div class="col">
        <label>Contact</label>
        <input type="number" class="form-control" id="contact" name="contact" value="<?php echo $contact; ?>" placeholder="Enter Phone Number" required="required" style="font-family: 'Poppins';">
      </div>

      <div class="col">
    <label>Marital Status</label>
    <select class="form-control" id="mstats" name="mstats" required="required" style="font-family: 'Poppins';">
        <option value="Single" <?php if($mstats == 'Single') echo 'selected'; ?>>Single</option>
        <option value="Married" <?php if($mstats == 'Married') echo 'selected'; ?>>Married</option>
        <option value="Widowed" <?php if($mstats == 'Widowed') echo 'selected'; ?>>Widowed</option>
        <option value="Separated" <?php if($mstats == 'Separated') echo 'selected'; ?>>Separated</option>
    </select>
</div>
        </div>

    <div class="row">
      <div class="col">
        <label>Gender</label>
        <select class="form-control" id="gender" name="gender" value="<?php echo $gender; ?>" style="font-family: 'Poppins';">
          <option value="Male" <?php if($gender == 'Male') echo 'selected'; ?>>Male</option>
          <option value="Female" <?php if($gender == 'Female') echo 'selected'; ?>>Female</option>
        </select>
      </div>

      <div class="col">
        <label>Address</label>
        <input type="text" class="form-control" id="addrss" name="addrss" value="<?php echo $addrss; ?>" placeholder="Enter Address" style="font-family: 'Poppins';">
      </div>
    </div>
    </div>


    <div class="row">
    <div class="col">
        <label>Email</label>
        <input type="text" class="form-control" id="email" name="email" value="<?php echo $email; ?>" placeholder="Enter Address" style="font-family: 'Poppins';">
      </div>
<br>
      <h4>Educational Background : </h4>

      <div class="row">
        <div class="col">
        <label>Last School Attended</label>
        <input type="text" class="form-control" id="scl" name="scl" value="<?php echo $scl; ?>" placeholder="Your Last School Attended(Complete)" style="font-family: 'Poppins';">
      </div>
  
    <div class="col">
        <label>Degree</label>
        <input type="text" class="form-control" id="deg" name="deg" value="<?php echo $deg; ?>" placeholder="Enter your Degree" style="font-family: 'Poppins';">
    </div>
    </div>

    <div class="row">
        <div class="col">
        <label>Skills</label>
        <input type="text" class="form-control" id="skills" name="skills" value="<?php echo $skills; ?>" placeholder="Enter your Skills" style="font-family: 'Poppins';">
      </div>

        <div class="col">
        <label>Credentials</label>
        <input type="text" class="form-control" id="cred" name="cred" value="<?php echo $cred; ?>" placeholder="Enter your Credentials" style="font-family: 'Poppins';">
      </div>
      </div>

      <div class="row">
      <div class="col">
        <label for="img">Please upload a new JPG or PNG file:</label><br>
        <div id="file-upload-container">
            <button type="button" class="btn-secondary">
                <i class="fa fa-upload"></i> Upload
                <input type="file" id="img" name="img" style="font-family: 'Poppins';">
                <span id="file-name"></span>
            </button>
        </div>
        <p style="font-family: 'Poppins';">Previews Photo : <?php echo $img; ?></p>
    </div>

    <div class="col"></div>
</div>

      

        <script>
  document.getElementById('img').addEventListener('change', function() {
    var fileName = this.files[0].name;
    document.getElementById('file-name').textContent = fileName;
  });
</script>

        

        <div class="col">
   
        </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-lg" id="register">Edit</button>
      </div>
    </div>
    </form>
  </div>
</div>

<div class="row">
    <div class="col">
    <?php
    if(isset($_SESSION['status'])){
?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-40 start-50 translate-middle-x" role="alert" style="z-index: 10000;">
<h4><?php echo $_SESSION['status']; ?></h4>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['status']);
    }
?>

<?php
    if(isset($_SESSION['istatus'])){
?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-40 start-50 translate-middle-x" role="alert" style="z-index: 10000;">
<h4><?php echo $_SESSION['istatus']; ?></h4>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['istatus']);
    }
?>
    </div>
          
</div> 
<!-----------------------------------VIEW-------------------------------->    

      <form action="" method="POST" id="form" style="background-color: #fff;">
      <div class="main--content">
      <div class="header--wrapper">
        <div class="header--title">
          <h4 style=" font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;">&nbsp;<?php echo $fname; ?></h4>
  <br>
            <input type="hidden" id="id" name="id" value="<?php echo isset($row['id']) ? $row['id'] : ''; ?>">

      <div class="row">
      <div class="col">
      <fieldset disabled>
    <label>Employee's ID</label>
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['empid']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
      </fieldset>
      </div>
      
  
      <div class="col">
      <fieldset disabled>
    <label >Contact</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['contact']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>
</div>

      <div class="row">
      <div class="col">
      <fieldset disabled>
    <label>Birthdate</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo date('F j, Y', strtotime($row['bdate'])); ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>

      <div class="col">
      <fieldset disabled>
    <label>Department</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['dept']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
     </div>

</div>

      <div class="row">
      <div class="col">
      <fieldset disabled>
    <label>Marital Status</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['mstats']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>

      <div class="col">
      <fieldset disabled>
    <label>Gender</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['gender']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>
</div>

      <div class="row">
      <div class="col">
      <fieldset disabled>
    <label>Address</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['addrss']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>
      
      <div class="col">
      <fieldset disabled>
    <label>Email</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['email']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>
</div>

<h4 style=" font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex;">Educational Background :</h4>
     
        <div class="row">
        <div class="col">
        <fieldset disabled>
        <div class="mb-3">
        <label>Last School Attended</label>
        <input type="text" class="form-control" id="scl" name="scl" value="<?php echo $row['scl']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
          </div>
        </fieldset>
      </div>
    
    <div class="col">
    <fieldset disabled>
    <div class="mb-3">
        <label>Degree</label>
        <input type="text" class="form-control" id="deg" name="deg"  value="<?php echo $row['deg']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
</div>
      </fieldset>
    </div>
        </div>

     
        <div class="row">
        <div class="col">
        <fieldset disabled>
        <div class="mb-3">
        <label>Skills :</label>
        <input type="text" class="form-control" id="skills" name="skills"  value="<?php echo $row['skills']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
</div>
      </fieldset>
      </div>

     
      <div class="col">
      <fieldset disabled>
      <div class="mb-3">
        <label>Credentials :</label>
        <input type="text" class="form-control" id="cred" name="cred"  value="<?php echo $row['cred']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
      </div>
</fieldset>   
    </div>
</div>

      <div class="col">

      </div>
      </div>
<!--------------------------------------------------------------------------------------------->


      <div class="row">
              <div class="col-lg-2">
            <a class="btn btn-success form-control" style="font-size: 12px; font-family: 'Poppins';" id="register" href="view.php?">BACK</a>
        </div>

        <div class="col"></div>
        <div class="col"></div>
        <div class="col"></div>
        <div class="col"></div>
        <div class="col"></div>
        <div class="col"></div>
        <div class="col"></div>
        <div class="col"></div>
      <div class="col">    
              <a class="btn btn-success form-control" style="font-size: 12px; font-family: 'Poppins';" id="register" data-bs-toggle="modal" data-bs-target="#eModal">EDIT</a>
            </div>
            </div>
</div>
    
  </div>
            </div>
                      </div>
                      </form>
</body>
</html>