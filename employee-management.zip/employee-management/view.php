<?php
include_once 'dbconnection.php'; 

$page_no = isset($_GET['page_no']) && $_GET['page_no'] !== "" ? (int)$_GET['page_no'] : 1;
$total_records_per_page = 10;
$offset = ($page_no - 1) * $total_records_per_page;

$sql = "SELECT * FROM `register` WHERE `empid` IS NOT NULL AND `empid` <> '' AND archived = 'On Duty' ORDER BY `fname` ASC LIMIT $offset, $total_records_per_page";
$query = mysqli_query($conn, $sql);

if (!$query) {
    die("Error: " . mysqli_error($conn));
}
$total_records_query = "SELECT COUNT(*) as total_records FROM `register` WHERE `empid` IS NOT NULL AND `empid` <> '' AND `archived` = 'INACTIVE'";
$total_records_result = mysqli_query($conn, $total_records_query);
$total_records = mysqli_fetch_assoc($total_records_result)['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="icon" href="image/e3.png">
      <link rel="stylesheet" href="css/view.css">
      <title>ADMIN -  EMPLOYEE LISTS</title>
      <style>
        .status-dot {
            height: 10px;
            width: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 5px;
            vertical-align: middle;
        }
        .status-online {
            background-color: green;
        }
        .status-offline {
            background-color: red;
        }
    </style>
</head>
<body>
<?php
include_once 'admin_sidebar.php';
?>
 <div class="main--content">
      <div class="header--wrapper">
        <div class="header--title">
        <h4 style="font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;">&nbsp;&nbsp;LIST OF EMPLOYEE</h4>

    <div class="dropdown">
    <button class="btn btn-primary btn-sm dropdown-toggle" id="back" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false" style="position: absolute; left: 15px; top: 70px;">
        ALL
    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <li><a class="dropdown-item" href="view.php">ALL</a></li>
         <li><a class="dropdown-item" href="archive.php">ARCHIVED</a></li>
    </ul>
</div>

<br><br>
</div>
  </div>
  <div class="row">
    <div class="col"></div>
    <div class="col">
        <input type="text" id="getName" class="form-control" style="width: 250px; position: absolute; right: 10px; top: 30px;" placeholder="Search"/>
    </div>
</div>
 <script>
    $(document).ready(function(){
        $('#getName').on("keyup", function(){
            var getName = $(this).val();
            $.ajax({
                method:'POST',
                url:'action.php',
                data:{name:getName},
                success:function(response) {
                    $("#showdata").html(response);  
                }
            });  
        });
    });
    </script>
<br>
<br>

        <div class="table-responsive" id="table1">
        <table class="table table-bordered">
            <thead>
            <tr style="text-align: center;">
                    <th>Profile</th>
                    <th>Employee's Fullname</th>
                    <th>Employee's ID</th>
                    <th>Department</th>
                    <th>Date Created</th>
                    <th>Length of Service</th>
                    <th>Work Tasks</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="showdata">
    
            <?php
$current_date = date("F j, Y");

while ($row = mysqli_fetch_assoc($query)) {
    $created_date = new DateTime($row['cdate']);
    $interval = $created_date->diff(new DateTime($current_date));

    $duration = $interval->format('%y years, %m months, %d days');
    $duration = str_replace(array('0 years,', '0 months,', '0 days,'), '', $duration);
    $duration = trim($duration);

    $status_dot = $row["user_status"] == "Online" ? "<span class='status-dot status-online'></span>" : "<span class='status-dot status-offline'></span>";

    $profile_path = 'profile/' . $row['img'];
    echo "<tr style='text-align: center;'><td><img src='" . $profile_path . "' class='rounded-circle' width='50px' alt='IMAGE'></td>
    <td>".$row['fname']."</td><td>".$row['empid']."</td>
    <td>".$row['dept']."</td>
    <td>".$row['cdate']."</td>
    <td>".$duration."</td>
    <td text-align: center;'>".$row['archived']."</td>
    <td style='text-align: center;'>" . $status_dot . htmlspecialchars($row["user_status"]) . "</td>
    <td>
    <a href='view_empinfo.php?id=".$row['id']."' class='btn btn-primary btn-sm' id='btn'>VIEW</a>
    &nbsp;<a href='arch.php?' class='btn btn-danger btn-sm' id='btn' onclick=\"confirmDelete(event, ".$row['empid'].", '".$row['fname']."');\">ARCHIVE</a></td>
    </tr>";
}
?>
            </tbody>
        </table>
</div>

       
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item <?php echo $page_no <= 1 ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page_no=<?php echo $page_no - 1; ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_no_of_pages; $i++) : ?>
                    <li class="page-item <?php echo $page_no == $i ? 'active' : ''; ?>">
                        <a class="page-link" href="?page_no=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?php echo $page_no >= $total_no_of_pages ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page_no=<?php echo $page_no + 1; ?>">Next</a>
                </li>
            </ul>
                </nav>
    

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmDelete(event, empid, name) {
        event.preventDefault();
        Swal.fire({
            title: 'Archive ' + name + '?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#135D66',
            confirmButtonText: 'Archive',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                deleteInfo(empid, name);
            } else {
                Swal.fire({
                    title:  'Archive operation was canceled.',
                    icon: 'info',
                    confirmButtonColor: '#135D66',
                    confirmButtonText: 'OK'
                });
            }
        });
    }

    function deleteInfo(empid, name) {
        fetch('arch.php?archiveid=' + empid)
            .then(response => {
                if (response.ok) {
                    return response.text();
                } else {
                    throw new Error('Network response was not ok');
                }
            })
            .then(data => {
                Swal.fire({
                    title: 'Successfully Archived ' + name,
                    icon: 'success',
                    confirmButtonColor: '#135D66',
                    confirmButtonText: 'OK'
                });
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'Error',
                    text: 'An error occurred while archiving the employee.',
                    icon: 'error',
                    confirmButtonColor: '#135D66',
                    confirmButtonText: 'OK'
                });
            });
    }
</script>
  </body>
  </html>