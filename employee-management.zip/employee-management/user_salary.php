<?php 
include 'dbconnection.php';

if(isset($_GET["empid"])){
    $id = $_GET['empid'];

    $sql = "SELECT * FROM `register` WHERE `empid` = ? ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fname = $row['fname'];
    } else {
        echo "No matching record found for id: $id";
    }

    $stmt->close();

    $sql_salary = "SELECT s.*, r.fname FROM `salary` s INNER JOIN `register` r ON s.empid = r.empid WHERE s.empid = ? ORDER BY s.id DESC";
    $stmt_salary = $conn->prepare($sql_salary);
    $stmt_salary->bind_param("i", $id);
    $stmt_salary->execute();
    $result_salary = $stmt_salary->get_result();
    $stmt_salary->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png"> 
    <link rel="stylesheet" href="css/view.css">
    <title><?php echo $fname; ?></title>
</head>
<body>
<?php include_once 'user_sidebar.php'; ?>

<div class="main--content">
    <div class="header--wrapper">
        <div class="header--title">
            <h4 style=" font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;">SALARY INSIGHTS</h4>
        </div>
    </div>
<br>
<div class="table-responsive">
    <table class="table" id="tbl">
        <br>
        <thead>
            <tr>
                <th>Salary</th>
                <th>Deductive Reason</th>
                <th>Total Deduction</th>
                <th>Total Salary</th>
                <th>Date Created</th>
                <th>Last Updated</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if(isset($result_salary) && $result_salary->num_rows > 0) {
                while ($rows = $result_salary->fetch_assoc()) {
            ?>
            <tr>
                <td>₱<?php echo number_format($rows['salary'], 2); ?></td>
                <td>
                    <?php if ($rows['ph']): ?>
                        Philhealth<br>
                    <?php endif; ?>
                    <?php if ($rows['dss']): ?>
                        SSS<br>
                    <?php endif; ?>
                    <?php if ($rows['pagibig']): ?>
                        Pagibig<br>
                    <?php endif; ?>
                    <?php if ($rows['tax']): ?>
                        Tax<br>
                    <?php endif; ?>
                    <?php if (!$rows['ph'] && !$rows['dss'] && !$rows['pagibig'] && !$rows['tax']): ?>
                        no data.<br>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="printable-content">
                        <?php if ($rows['ph']): ?>
                            ₱<?php echo number_format($rows['ph']); ?><br>
                        <?php endif; ?>
                        <?php if ($rows['dss']): ?>
                            ₱<?php echo number_format($rows['dss']); ?><br>
                        <?php endif; ?>
                        <?php if ($rows['pagibig']): ?>
                            ₱<?php echo number_format($rows['pagibig']); ?><br>
                        <?php endif; ?>
                        <?php if ($rows['tax']): ?>
                            ₱<?php echo number_format($rows['tax']); ?><br>
                        <?php endif; ?>
                        <?php if ($rows['ph'] || $rows['dss'] || $rows['pagibig'] || $rows['tax'] || $rows['deduct']): ?>
                            <hr style="border: 2px solid; color: #000; border-radius: 5px;">
                        <?php endif; ?>
                        <?php if ($rows['deduct']): ?>
                            Total Deduction : ₱<?php echo number_format($rows['deduct']); ?><br>
                        <?php endif; ?>
                        <?php if (!$rows['ph'] && !$rows['dss'] && !$rows['pagibig'] && !$rows['tax'] && !$rows['deduct']): ?>
                            no data.<br>
                        <?php endif; ?>
                    </div>
                </td>
                <td>₱<?php echo number_format($rows['tsalary'], 2); ?></td>
                <td><?php echo $rows['datee']; ?></td>
                <td><?php echo $rows['udatee']; ?></td>
            </tr>
            <?php 
                }
            } else {    
            ?>
            <tr>
                <td colspan="7">No salary records found.</td>
            </tr>
            <?php 
            }
            ?>
        </tbody>
    </table>
    </div>
</div>

</body>
</html>
