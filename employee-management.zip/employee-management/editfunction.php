<?php
include 'dbconnection.php';

$id = $_POST['id'];
$fname = $_POST['fname'];
$empid = $_POST['empid'];
$dept = $_POST['dept'];
$contact = $_POST['contact'];
$bdate = $_POST['bdate'];
$mstats = $_POST['mstats'];
$gender = $_POST['gender'];
$addrss = $_POST['addrss'];
$email = $_POST['email'];
$udate = $_POST['udate'];
$scl = $_POST['scl'];
$deg = $_POST['deg'];
$skills = $_POST['skills'];
$cred = $_POST['cred'];

$user_id = 1;

function action_made($conn, $user_id, $action_made) {
    $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
    $stmt->bind_param("is", $user_id, $action_made);
    if (!$stmt->execute()) {
        echo "Error executing action_made statement: " . $stmt->error;
    }
    $stmt->close();
}

function fetchEmployeeName($conn, $empid) {
    $stmt = $conn->prepare("SELECT fname FROM register WHERE empid=?");
    $stmt->bind_param("s", $empid);
    $stmt->execute();
    $stmt->bind_result($fname);
    $stmt->fetch();
    $stmt->close();
    return $fname;
}

if(isset($_FILES['img']) && $_FILES['img']['error'] === UPLOAD_ERR_OK) {
    $img = $_FILES['img']['name'];
    $directory = 'profile/';
    $filename = $_FILES['img']['name'];
    $profile_tmp = $_FILES['img']['tmp_name'];

    if(move_uploaded_file($profile_tmp, $directory.$filename)) {
        $query = "UPDATE register SET fname=?, empid=?, dept=?, contact=?, bdate=?, mstats=?, gender=?, addrss=?, email=?, udate=?, scl=?, deg=?, skills=?, cred=?, img=? WHERE id=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssssssssssssi", $fname, $empid, $dept, $contact, $bdate, $mstats, $gender, $addrss, $email, $udate, $scl, $deg, $skills, $cred, $filename, $id);
        $result = $stmt->execute();

        if($result) {
            session_start();
            action_made($conn, $user_id, "Updated $fname's Image");
            $_SESSION['istatus'] = "IMAGE UPDATED SUCCESSFULLY";
            header("Location: view_empinfo.php?id=$id");
            exit();
        } else {
            session_start();
            $_SESSION['fstatus'] = "NOT UPDATED";
            header("Location: view_empinfo.php?id=$id");
            exit();
        }
    } else {
        session_start();
        $_SESSION['fstatus'] = "Failed to edit information.";
        header("Location: view_empinfo.php?id=$id");
        exit();
    }
} else {
    $query = "UPDATE register SET fname=?, empid=?, dept=?, contact=?, bdate=?, mstats=?, gender=?, addrss=?, email=?, udate=?, scl=?, deg=?, skills=?, cred=? WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssssssssssssi", $fname, $empid, $dept, $contact, $bdate, $mstats, $gender, $addrss, $email, $udate, $scl, $deg, $skills, $cred, $id);

    $result = $stmt->execute();

    $query_salary = "UPDATE salary SET fname=? WHERE empid=?";
$stmt_salary = $conn->prepare($query_salary);
$stmt_salary->bind_param("ss", $fname, $empid);
$result_salary = $stmt_salary->execute();

if (!$result_salary) {
    throw new Exception("Failed to update salary table.");
}

$query_leave = "UPDATE leave_notice SET fname=? WHERE empid=?";
$stmt_leave = $conn->prepare($query_leave);
$stmt_leave->bind_param("ss", $fname, $empid);
$result_leave = $stmt_leave->execute();

if (!$result_leave) {
    throw new Exception("Failed to update leave table.");
}

$conn->commit();

    if($result) {
        session_start();
        action_made($conn, $user_id, "Updated $fname's Information");
        $_SESSION['status'] = "INFOMATION UPDATED SUCCESSFULLY";
        header("Location: view_empinfo.php?id=$id");
        exit();
    } else {
        session_start();
        $_SESSION['fstatus'] = "IMAGE CAN'T UPDATE AT THIS TIME";
        header("Location: view_empinfo.php?id=$id");
        exit();
    }
}

?>
