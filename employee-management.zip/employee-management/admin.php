<?php
    $servername = "localhost"; 
    $dbname = "emp_db"; 

    date_default_timezone_set('Asia/Manila');

    $conn = new mysqli($servername, "root", "", $dbname);

  
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $adminid = "";
    
    $sql = "SELECT COUNT(*) AS employee_count FROM register where adminid='$adminid' && archived = 'On Duty'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      
        while($row = $result->fetch_assoc()) {
            $employee_count = $row["employee_count"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS request_count FROM leave_notice WHERE archived = 'On Duty'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $request_count = $row["request_count"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS request_pending FROM leave_notice WHERE apprv = 'PENDING' && archived = 'On Duty'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $request_pending = $row["request_pending"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS request_approved FROM leave_notice WHERE apprv = 'APPROVED' && archived = 'On Duty'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $request_approved = $row["request_approved"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS request_rejected FROM leave_notice WHERE apprv = 'REJECTED' && archived = 'On Duty'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $request_rejected = $row["request_rejected"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS department_count FROM department";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $department_count = $row["department_count"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS salary_count FROM salary WHERE archived = 'On Duty'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $salary_count = $row["salary_count"];
        }
    } else {
        $employee_count = 0;
    }
    $conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <link rel="icon" href="image/e3.png"> 
  <link rel="stylesheet" href="css/admina1.css">
    <title>WELCOME ADMIN</title>
</head>
<body>

<?php
include_once 'admin_sidebar.php';
?>

 <div class="main--content">
      <div class="header--wrapper" style="background-color: #135D66;">
        <div class="header--title">
          <h4 style="color: #fff; font-weight: bold; height: 50px; display: flex; align-items: center;">&nbsp;&nbsp;WELCOME ADMIN</h4>
</div>
  </div>

  <div class="row">
<div class="col"></div>
<div class="col-lg-2">
<a href="admin_activities.php" id="editButton">Activity Logs</a>
</div>
  </div>
  
  <div class="container">
    <div class="row">
        <div class="col-xl-3">
            <div class="card mt-3">
                <div class="card-header text-white" style="background: #135D66">
                    <h6 class="card-title mb-0">Registered Employees</h6>
                </div>
                <div class="card-body">
                    <p class="card-text fs-5"> <i class="fa-solid fa-users"></i> Active Staff : <?php echo $employee_count; ?></p>
                </div>
                <div class="card-footer text-muted" style="background-color: #fff;">
                    <small>Last updated: <?php echo date("F j, Y"); ?></small>
                </div>
            </div>
        </div>

        <div class="col-xl-3">
            <div class="card mt-3">
                <div class="card-header text-white" style="background: #135D66">
                    <h6 class="card-title mb-0">Departments</h6>
                </div>
                <div class="card-body">
                    <p class="card-text fs-5"><i class="fa-solid fa-building"></i> Departments : <?php echo $department_count; ?></p>
                </div>
                <div class="card-footer text-muted" style="background-color: #fff;">
                    <small>Last updated: <?php echo date("F j, Y"); ?></small>
                </div>
            </div>
        </div>

        <div class="col-xl-3">
            <div class="card mt-3">
                <div class="card-header text-white" style="background: #135D66">
                    <h6 class="card-title mb-0">Salaries</h6>
                </div>
                <div class="card-body">
                    <p class="card-text fs-5"><i class="fa-solid fa-dollar"></i> Salaries : <?php echo $salary_count; ?></p>
                </div>
                <div class="card-footer text-muted" style="background-color: #fff;">
                    <small>Last updated: <?php echo date("F j, Y"); ?></small>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3" >
            <div class="card mt-3">
                <div class="card-header text-white" style="background: #135D66">
                <h6 class="card-title mb-0">Leave Requests <?php echo $request_count; ?></h6>
                </div>
                <div class="card-body ">
                <p class="card-text fs-5"><i class="fa-solid fa-message"></i> Pending : <?php echo $request_pending; ?></p>
                </div>
                <div class="card-footer text-muted" style="background-color: #fff;">
                    <small>Last updated: <?php echo date("F j, Y"); ?></small>
                </div>
            </div>
        </div>
        </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>