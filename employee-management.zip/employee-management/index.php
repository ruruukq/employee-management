<!DOCTYPE html>
<html lang="en">
<head>
    <title>EMPLOYEE MANAGEMENT</title>
    <link rel="stylesheet" href="css/index5.css">
    <link rel="icon" href="image/e3.png"> 
</head>
<body>

    <div class="wave-header">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
  <path fill="#fff" fill-opacity="1" d="M0,192L80,165.3C160,139,320,85,480,90.7C640,96,800,160,960,154.7C1120,149,1280,75,1360,37.3L1440,0L1440,320L1360,320C1280,320,1120,320,960,320C800,320,640,320,480,320C320,320,160,320,80,320L0,320Z"></path>
</svg>

    <h1>WELCOME TO<br>EMPLOYEE MANAGEMENT</h1>

    <div class="col">
    <br>
          <a href="login.php"><input type="submit" id="submit" class="form-control" name="submit" value="GET STARTED"></a>
</div>
    </div>
    
</body>
</html>
