<?php
include 'dbconnection.php';

date_default_timezone_set('Asia/Manila');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
}

if (isset($_GET["id"])) {
}

$sql = "SELECT *, (salary - deduct) AS tsalary FROM salary ORDER BY id DESC";

$page_no = isset($_GET['page_no']) && $_GET['page_no'] !== "" ? (int)$_GET['page_no'] : 1;
$total_records_per_page = 10;
$offset = ($page_no - 1) * $total_records_per_page;

$sql = "SELECT *, (salary - deduct) AS tsalary FROM salary WHERE archived = 'On Duty' AND `empid` IS NOT NULL AND `empid` <> '' GROUP BY empid ORDER BY fname LIMIT $offset, $total_records_per_page";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Error: " . mysqli_error($conn));
}

$total_records_query = "SELECT COUNT(DISTINCT fname) as total_records FROM `salary` WHERE `empid` IS NOT NULL AND `empid` <> ''";
$total_records_result = mysqli_query($conn, $total_records_query);
$total_records = mysqli_fetch_assoc($total_records_result)['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <link rel="icon" href="image/e3.png">  
  <link rel="stylesheet" href="css/view.css">
    <title>ADMIN - EMPLOYEE SALARY</title>
</head>
<body>

<?php
include_once 'admin_sidebar.php';
?>
 <div class="main--content">
      <div class="header--wrapper">
        <div class="header--title">
          <h4 style=" font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;">&nbsp;SALARY INSIGHTS</h1>
</div>
</div>
<div class="row">
                <div class="col"></div>

<div class="col">
<input type="text" id="getName" class="form-control" style="width: 250px; position: absolute; right: 20px; top: 30px;" placeholder="Search"/>
</div> 
<script>
    $(document).ready(function(){
        $('#getName').on("keyup", function(){
            var getName = $(this).val();
            $.ajax({
                method:'POST',
                url:'act_salary.php',
                data:{name:getName},
                success:function(response) {
                    $("#showdata").html(response);  
                }
            });  
        });
    });
    </script>

  <!----------------------------------------ADD-------------------------------------->
  <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header" style="background: #137d74; color: #fff;">
        <h1 class="modal-title fs-5" id="exampleModalLabel">ADD SALARY</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="salaryadd.php" method="POST">
        <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
          <div class="col">
            <label>Employee's Fullame</label>
            <select class="form-control" id="fname" name="fname" onchange="updateEmpId(this.value)" required="required" style="font-size: 12px;">
              <option VALUE="">Select Name</option>
              <?php
                include 'dbconnection.php';
                $query = mysqli_query($conn, "SELECT * FROM register WHERE `adminid` = '$id' AND archived = 'On Duty' AND empid IS NOT NULL AND empid != '' ORDER BY fname");
                while ($res = mysqli_fetch_array($query)) {
                  echo '<option value="' . htmlentities($res['fname']) . '">' . htmlentities($res['fname']) . '</option>';
                }
                ?>
            </select>
          </div>
          <div class="col">
            <label>Employee's ID</label>
            <input type="text" class="form-control" id="empid" name="empid" style="font-size: 12px;" readonly>
          </div>
          
          <div class="col">
            <label for="salary">Salary</label>
            <input type="text" class="form-control" id="salary" name="salary" placeholder="Enter Employee's Salary" required="required" style="font-size: 12px;">
          </div>

          
          <div class="mb-3">
            <label>SSS</label>
            <div id="SSSContainer">
            <input type="text" class="form-control" name="dss" id="dss" placeholder="Enter SSS" style="font-size: 12px; display: none;">
            </div>
            <div id="additionalSSSContainer">
        <button type="button" id="addDss" class="btn btn-success btn-sm" style="font-size: 12px;">Add SSS</button>
        <button type="button" id="cancelDss" class="btn btn-danger btn-sm" style="font-size: 12px; display: none;">Cancel</button>
    </div>
    </div>

    <div class="mb-3">
            <label>Philhealth</label>
            <div id="phContainer">
            <input type="text" class="form-control" name="ph" id="ph" placeholder="Enter Philheatlh" style="font-size: 12px; display: none;">
            </div>
            <div id="additionalphContainer">
        <button type="button" id="addph" class="btn btn-success btn-sm" style="font-size: 12px;">Add Philhealth</button>
        <button type="button" id="cancelph" class="btn btn-danger btn-sm" style="font-size: 12px; display: none;">Cancel</button>
    </div>
    </div>

    <div class="mb-3">
            <label>Pagibig</label>
            <div id="pagibigContainer">
            <input type="text" class="form-control" name="pagibig" id="pagibig" placeholder="Enter Pagibig" style="font-size: 12px; display: none;">
            </div>
            <div id="additionalpagibigContainer">
        <button type="button" id="addpagibig" class="btn btn-success btn-sm" style="font-size: 12px;">Add Pagibig</button>
        <button type="button" id="cancelpagibig" class="btn btn-danger btn-sm" style="font-size: 12px; display: none;">Cancel</button>
    </div>
    </div>
    <div class="mb-3">
            <label>Tax</label>
            <div id="taxContainer">
            <input type="text" class="form-control" name="tax" id="tax" placeholder="Enter Tax" style="font-size: 12px; display: none;">
            </div>
            <div id="additionaltaxContainer">
        <button type="button" id="addtax" class="btn btn-success btn-sm" style="font-size: 12px;">Add Tax</button>
        <button type="button" id="canceltax" class="btn btn-danger btn-sm" style="font-size: 12px; display: none;">Cancel</button>
    </div>
    </div>

          <div class="mb-3">
            <label>Date Created</label>
            <input class="form-control" value="<?php echo date('F j, Y');?>" readonly="readonly" name="datee" style="font-size: 12px;">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-lg" id="update">ADD</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!----------------------------------------------------------------------------------->
<!---------------------------------------ADD NOTIF----------------------------------->
  <div class="row">
    <div class="col">
    <?php
    if(isset($_SESSION['status'])){
?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4><?php echo $_SESSION['status']; ?></h4>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['status']);
    }
?>
 </div>
<!-------------------------------------------------------------------------------------->
            <script>
        function updateEmpId(selectedName) {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("empid").value = this.responseText;
                }
            };
            xhttp.open("GET", "fetch_empid.php?fname=" + selectedName, true);
            xhttp.send();
        }
    </script>
<br>
<!---------------------------------------------------------------------------------->

<!--------------------------------------VIEW---------------------------------------->
<div class="col">
    <button type="button" class="btn btn-primary" id="back" data-bs-toggle="modal" data-bs-target="#addModal" style="position: absolute; left: 20px; top: 80px;">
  ADD
</button>
</div> 
    </div>
<br><br><br>
<div class="table-responsive">
    <table class="table" id="tbl">
        <br>
        <tr>
            <th>Employee's Fullname</th>
            <th>Employee's ID</th>
            <th>Date Created</th>
            <th style="text-align: center;">Action</th>
        </tr>
        <tbody id="showdata">
    <?php foreach ($result as $rows): ?>
        <tr>
            <td><?php echo $rows['fname']; ?></td>
            <td><?php echo $rows['empid']; ?></td>
            <td><?php echo $rows['datee']; ?></td>
            <td  style="text-align: center;">
                <a href="salaryview.php?empid=<?php echo $rows['empid']; ?>" class='btn btn-primary btn-sm' id="btn">VIEW</a>
            </td>
        </tr>
    <?php endforeach; ?>
</tbody>

    </table>

<!---------------------------------------------------------------------------------->

<!----------------------------------PAGINATION-------------------------------------->
    <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item <?php echo $page_no <= 1 ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page_no=<?php echo $page_no - 1; ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_no_of_pages; $i++) : ?>
                    <li class="page-item <?php echo $page_no == $i ? 'active' : ''; ?>">
                        <a class="page-link" href="?page_no=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?php echo $page_no >= $total_no_of_pages ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page_no=<?php echo $page_no + 1; ?>">Next</a>
                </li>
            </ul>
                </nav>
  </div>
    </div>

<!------------------------------------------------------------------------------------>



<!------------------------------------SSS--------------------------------------------->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        let deductionCount = 1;

        function addDeductionInput() {
            const container = document.getElementById('SSSContainer');
            const input = document.createElement('input');
            input.type = 'text';
            input.classList.add('form-control', 'mb-2');
            input.placeholder = 'Enter SSS';
            input.style.fontSize = '12px';
            input.name = 'dss';
            input.required = true;
            container.appendChild(input);
            deductionCount++;
            toggleCancelVisibility(true);
        }

        function toggleCancelVisibility(show) {
            const cancelButton = document.getElementById('cancelDss');
            cancelButton.style.display = show ? 'inline-block' : 'none';
        }

        document.getElementById('addDss').addEventListener('click', addDeductionInput);

        document.getElementById('cancelDss').addEventListener('click', function() {
            const container = document.getElementById('SSSContainer');
            container.removeChild(container.lastElementChild); 
            deductionCount--;
            toggleCancelVisibility(deductionCount > 1);
        });
    });
</script>
<!------------------------------------------------------------------------>

<!-------------------------------PH--------------------------------------->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        let deductionCount = 1;

        function addDeductionInput() {
            const container = document.getElementById('phContainer');
            const input = document.createElement('input');
            input.type = 'text';
            input.classList.add('form-control', 'mb-2');
            input.placeholder = 'Enter Philhealth';
            input.style.fontSize = '12px';
            input.name = 'ph';
            input.required = true;
            container.appendChild(input);
            deductionCount++;
            toggleCancelVisibility(true);
        }

        function toggleCancelVisibility(show) {
            const cancelButton = document.getElementById('cancelph');
            cancelButton.style.display = show ? 'inline-block' : 'none';
        }

        document.getElementById('addph').addEventListener('click', addDeductionInput);

        document.getElementById('cancelph').addEventListener('click', function() {
            const container = document.getElementById('phContainer');
            container.removeChild(container.lastElementChild); 
            deductionCount--;
            toggleCancelVisibility(deductionCount > 1);
        });
    });
</script>
<!------------------------------------------------------------------------------------>

<!---------------------------------------PAGIBIG-------------------------------------->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        let deductionCount = 1;

        function addDeductionInput() {
            const container = document.getElementById('pagibigContainer');
            const input = document.createElement('input');
            input.type = 'text';
            input.classList.add('form-control', 'mb-2');
            input.placeholder = 'Enter Pagibig';
            input.style.fontSize = '12px';
            input.name = 'pagibig';
            input.required = true;
            container.appendChild(input);
            deductionCount++;
            toggleCancelVisibility(true);
        }

        function toggleCancelVisibility(show) {
            const cancelButton = document.getElementById('cancelpagibig');
            cancelButton.style.display = show ? 'inline-block' : 'none';
        }

        document.getElementById('addpagibig').addEventListener('click', addDeductionInput);

        document.getElementById('cancelpagibig').addEventListener('click', function() {
            const container = document.getElementById('pagibigContainer');
            container.removeChild(container.lastElementChild); 
            deductionCount--;
            toggleCancelVisibility(deductionCount > 1);
        });
    });
</script>
<!------------------------------------------------------------------------------------>

<!-----------------------------------------TAX---------------------------------------->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        let deductionCount = 1;

        function addDeductionInput() {
            const container = document.getElementById('taxContainer');
            const input = document.createElement('input');
            input.type = 'text';
            input.classList.add('form-control', 'mb-2');
            input.placeholder = 'Enter Tax';
            input.style.fontSize = '12px';
            input.name = 'tax';
            input.required = true;
            container.appendChild(input);
            deductionCount++;
            toggleCancelVisibility(true);
        }

        function toggleCancelVisibility(show) {
            const cancelButton = document.getElementById('canceltax');
            cancelButton.style.display = show ? 'inline-block' : 'none';
        }

        document.getElementById('addtax').addEventListener('click', addDeductionInput);

        document.getElementById('canceltax').addEventListener('click', function() {
            const container = document.getElementById('taxContainer');
            container.removeChild(container.lastElementChild); 
            deductionCount--;
            toggleCancelVisibility(deductionCount > 1);
        });
    });
</script>
<!------------------------------------------------------------------------------------>
  </body>
  </html>
