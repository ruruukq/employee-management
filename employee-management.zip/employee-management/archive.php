    <?php
    include_once 'dbconnection.php'; 

    $page_no = isset($_GET['page_no']) && $_GET['page_no'] !== "" ? (int)$_GET['page_no'] : 1;
    $total_records_per_page = 10;
    $offset = ($page_no - 1) * $total_records_per_page;

    $sql = "SELECT * FROM `register` WHERE `archived` = 'INACTIVE' ORDER BY `fname` ASC LIMIT $offset, $total_records_per_page";
    $query = mysqli_query($conn, $sql);

    if (!$query) {
        die("Error: " . mysqli_error($conn));
    }

    $total_records_query = "SELECT COUNT(*) as total_records FROM `register` WHERE `archived` = 'ARCHIVE'";
    $total_records_result = mysqli_query($conn, $total_records_query);
    $total_records = mysqli_fetch_assoc($total_records_result)['total_records'];
    $total_no_of_pages = ceil($total_records / $total_records_per_page);
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="image/e3.png">
        <link rel="stylesheet" href="css/view.css">
        <title>ADMIN -  ARCHIVE</title>
    </head>
    <body>
    <?php
    include_once 'admin_sidebar.php';
    ?>
    <div class="main--content">
        <div class="header--wrapper">
            <div class="header--title">
            <h4 style="font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;">&nbsp;&nbsp;ARCHIVED ACCOUNTS</h4>
        
            <div class="dropdown">
        <button class="btn btn-primary btn-sm dropdown-toggle" id="back" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false" style="position: absolute; left: 15px; top: 70px;">
        ARCHIVED
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <li><a class="dropdown-item" href="view.php">ALL</a></li>
            <li><a class="dropdown-item" href="archive.php">ARCHIVED</a></li>
        </ul>
    </div>

    <br><br>
    </div>
    </div>
    <div class="row">
        <div class="col"></div>
        <div class="col">
            <input type="text" id="getName1" class="form-control" style="width: 250px; position: absolute; right: 10px; top: 30px;" placeholder="Search"/>
        </div>
    </div>
    <script>
    $(document).ready(function(){
        $('#getName1').on("keyup", function(){
            var getName1 = $(this).val();
            $.ajax({
                method:'POST',
                url:'action1.php',
                data:{name:getName1, archived:'INACTIVE'},
                success:function(response) {
                    $("#showdata").html(response);  
                }
            });  
        });
    });
    </script>

    <br>
    <br>

            <div class="table-responsive" id="table1">
            <table class="table table-bordered">
                <thead>
                    <tr style="text-align: center;">
                        <th>Profile</th>
                        <th>Employee's Fullname</th>
                        <th>Employee's ID</th>
                        <th>Department</th>
                        <th>Date Created</th>
                        <th>Length of Service</th>
                        <th>Archived Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="showdata">
        
                    <?php 
                $current_date = date("F j, Y");

                while ($row = mysqli_fetch_assoc($query)) {
                    $created_date = new DateTime($row['cdate']);
                    $interval = $created_date->diff(new DateTime($current_date));
                
                    $duration = $interval->format('%y years, %m months, %d days');
                    $duration = str_replace(array('0 years,', '0 months,', '0 days,'), '', $duration);
                    $duration = trim($duration);
                    $profile_path = 'profile/' . $row['img'];
                    echo "<tr style='text-align: center;'><td><img src='" . $profile_path . "' class='rounded-circle' width='50px' alt='IMAGE'></td>
                    <td>".$row['fname']."</td><td>".$row['empid']."</td>
                    <td>".$row['dept']."</td>
                    <td>".$row['cdate']."</td>
                    <td style='text-align: center;'>".$duration."</td>
                    <td>".$row['archive_date']."</td>
                    <td>
                    <a href='archive_change.php?' class='btn btn-danger btn-sm' id='btn' onclick=\"confirmDelete(event, ".$row['empid'].", '".$row['fname']."');\">RESTORE</a></td></tr>";              ;
                    }
                    ?>
                </tbody>
                <script>
        function redirectToOtherFile() {
            
            window.location.href = 'update.php';
        }
    </script>
            </table>
    </div>

        
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item <?php echo $page_no <= 1 ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?page_no=<?php echo $page_no - 1; ?>">Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $total_no_of_pages; $i++) : ?>
                        <li class="page-item <?php echo $page_no == $i ? 'active' : ''; ?>">
                            <a class="page-link" href="?page_no=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?php echo $page_no >= $total_no_of_pages ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?page_no=<?php echo $page_no + 1; ?>">Next</a>
                    </li>
                </ul>
                    </nav>
        

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function confirmDelete(event, empid, name) {
            event.preventDefault();
            Swal.fire({
                title: 'Restore ' + name + 'to the list?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#135D66',
                confirmButtonText: 'Restore',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    deleteInfo(empid, name);
                } else {
                    Swal.fire({
                        title:  'Restore operation was canceled.',
                        icon: 'info',
                        confirmButtonColor: '#135D66',
                        confirmButtonText: 'OK'
                    });
                }
            });
        }

        function deleteInfo(empid, name) {
            fetch('archive_change.php?restid=' + empid)
                .then(response => {
                    if (response.ok) {
                        return response.text();
                    } else {
                        throw new Error('Network response was not ok');
                    }
                })
                .then(data => {
                    Swal.fire({
                        title: 'Successfully Restored ' + name + ' to the list',
                        icon: 'success',
                        confirmButtonColor: '#135D66',
                        confirmButtonText: 'OK'
                    });
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'Error',
                        text: 'An error occurred while Restoring the employee.',
                        icon: 'error',
                        confirmButtonColor: '#135D66',
                        confirmButtonText: 'OK'
                    });
                });
        }
    </script>
    </body>
    </html>