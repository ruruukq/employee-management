<?php
    
    $servername = "localhost"; 
    $dbname = "emp_db"; 

    $conn = new mysqli($servername, "root", "", $dbname);

    $row = [];

if(isset($_GET["empid"])){
    $id = $_GET['empid'];

    $sql = "SELECT * FROM `register` WHERE `empid` = '$id'";

    $result = $conn->query($sql);

    if (!$result) {
        die("Error executing the query: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fname = $row['fname'];
    } else {
        echo "No matching record found for id: $id";
    }
}
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = "SELECT COUNT(*) AS request_count FROM leave_notice WHERE empid='$id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $request_count = $row["request_count"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS request_pending FROM leave_notice WHERE empid='$id' AND apprv = 'PENDING'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $request_pending = $row["request_pending"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS request_approved FROM leave_notice WHERE empid='$id' AND apprv = 'APPROVED'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $request_approved = $row["request_approved"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS request_rejected FROM leave_notice WHERE empid='$id' AND apprv = 'REJECTED'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $request_rejected = $row["request_rejected"];
        }
    } else {
        $employee_count = 0;
    }
    $sql = "SELECT COUNT(*) AS salary_count FROM salary WHERE empid='$id' ";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $salary_count = $row["salary_count"];
        }
    } else {
        $employee_count = 0;
    }
    $conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <link rel="icon" href="image/e3.png"> 
  <link rel="stylesheet" href="css/admina1.css">
    <title>WELCOME <?php echo $fname; ?></title>
</head>
<body>

<?php
include_once 'user_sidebar.php';
?>
 <div class="main--content">
      <div class="header--wrapper" style="background-color: #135D66;">
        <div class="header--title">
          <h4 style=" color: #fff; font-weight: bold; height: 50px; display: flex; align-items: center;">&nbsp;&nbsp;WELCOME <?php echo $fname; ?></h4>
</div>
  </div>

  <div class="row">
<div class="col"></div>
<div class="col-lg-2">
<a href="user_logs.php?empid=<?php echo isset($row['empid']) ? $row['empid'] : ""; ?>" id="editButton">Activity Logs</a>
</div>
  </div>

  <div class="container">
    <div class="row">
        <div class="col-xl-3">
            <div class="card mt-3">
                <div class="card-header text-white" style="background: #135D66">
                    <h6 class="card-title mb-0">Leave Requests : <?php echo $request_count; ?></h6>
                </div>
                <div class="card-body ">
                <p class="card-text fs-10"> Pending Request: <?php echo $request_pending; ?></p>
                    <p class="card-text fs-10">Approved Request: <?php echo $request_approved; ?></p>
                   
                    <p class="card-text fs-10">Rejected Request: <?php echo $request_rejected; ?></p>
                </div>
                <div class="card-footer text-muted" style="background-color: #fff;">
                    <small>Last updated: <?php echo date("Y-m-d"); ?></small>
                </div>
            </div>
        </div>

        <div class="col-xl-3">
    <div class="card mt-3" >
        <div class="card-header text-white" style="background: #135D66">
            <h6 class="card-title mb-0">Salaries</h6>
        </div>
        <div class="card-body md-6">
            <p class="card-text fs-5"><i class="fa-solid fa-dollar"></i> Salaries : <?php echo $salary_count; ?></p>
        </div>
        <div class="card-footer text-muted" style="background-color: #fff;">
            <small>Last updated: <?php echo date("Y-m-d"); ?></small>
        </div>
    </div>
</div>


    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>