<?php 
include 'dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $fname = $_POST['fname'];
    $empid = $_POST['empid'];
    $dept = $_POST['dept'];
    $contact = $_POST['contact'];
    $bdate = $_POST['bdate'];
    $mstats = $_POST['mstats'];
    $gender = $_POST['gender'];
    $addrss = $_POST['addrss'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $user = "USER";
    $cdate = $_POST['cdate'];
    $scl = $_POST['scl'];
    $deg = $_POST['deg'];
    $skills = $_POST['skills'];
    $cred = $_POST['cred'];
    $useer = "On Duty";
    $user_status = "Offline";
    $img = $_FILES['img']['name'];
    $directory = 'profile/';
    $filename = $_FILES['img']['name'];
    $profile_tmp = $_FILES['img']['tmp_name'];

    if(move_uploaded_file($profile_tmp, $directory.$filename)) {
    } else {
        die("Failed to upload image.");
    }

    $check_query = "SELECT * FROM `register` WHERE `email`='$email' OR `empid`='$empid'";
    $check_result = mysqli_query($conn, $check_query);
    if (mysqli_num_rows($check_result) > 0) {
        $_SESSION['istatus'] = "Someone already owned email or Employee's ID!";
        header("Location: login.php");
    } else {
        $sql = "INSERT INTO `register` (fname, empid, dept, contact, bdate, mstats, gender, addrss, email, pass, usertype, cdate, scl, deg, skills, cred, img, archived, user_status)
        VALUES ('$fname', '$empid', '$dept', '$contact', '$bdate', '$mstats', '$gender', '$addrss', '$email', '$pass', '$user', '$cdate', '$scl', '$deg', '$skills', '$cred', '$filename', '$useer', '$user_status')";

        $result = mysqli_query($conn, $sql);    
        if($result){
            $_SESSION['status'] = "SUCCESSFULLY REGISTERED!";
            header("Location: userdash.php?empid=" . $new_user_row['empid'] . "&id=" . $new_user_row['id']);
        } else{
            die(mysqli_error($conn));
            echo "<script>window.location = 'register.php'</script>";
        }
    }
}
?>
