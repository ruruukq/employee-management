<?php

include 'dbconnection.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $empid = $_POST['empid'];
    $msg = $_POST['msg'];
    $fromd = $_POST['fromd'];
    $tod = $_POST['tod'];
    $tdate = $_POST['tdate'];

    $user_id = $_SESSION['user_id'];

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            die("Error executing action_made statement: " . $stmt->error);
        }
        $stmt->close();
    }

    function editLeave($conn, $fname, $empid, $msg, $fromd, $tod, $tdate, $id, $user_id) {
        $query = "UPDATE leave_notice SET fname=?, empid=?, msg=?, fromd=?, tod=?, tdate=? WHERE id=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssssi", $fname, $empid, $msg, $fromd, $tod, $tdate, $id);

        $result = $stmt->execute();
        
        if ($result) {
            action_made($conn, $user_id, "Updated their Leave Request");
            $_SESSION['status'] = "LEAVE REQUEST UPDATED SUCCESSFULLY";
            header("Location: user_leaver.php?empid=$empid");
            exit(0);
        } else {
            $_SESSION['message'] = "NOT UPDATED";
            header("Location: user_leaveu.php?empid=$empid");
            exit();
        }
    }
    editLeave($conn, $fname, $empid, $msg, $fromd, $tod, $tdate, $id, $user_id);
}
?>
