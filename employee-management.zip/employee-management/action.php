<?php
include("dbconnection.php");

$name = $_POST['name'];

$current_date = date("F j, Y");

$sql = "SELECT * FROM `register` WHERE fname LIKE '$name%' AND empid IS NOT NULL AND empid != '' AND archived = 'ACTIVE' ORDER BY `fname`";
$query = mysqli_query($conn, $sql);

$data = '';
if(mysqli_num_rows($query) > 0) {
    while($row = mysqli_fetch_assoc($query)) {
        $created_date = new DateTime($row['cdate']);
        $interval = $created_date->diff(new DateTime($current_date));
        $duration = $interval->format('%y years, %m months, %d days');
        $duration = str_replace(array('0 years,', '0 months,', '0 days,'), '', $duration);
        $duration = trim($duration);

        $profile_path = 'profile/' . $row['img'];
        $data .= "<tr style='text-align: center;'><td><img src='" . $profile_path . "' class='rounded-circle' width='50px' alt='IMAGE'></td>
        <td>".$row['fname']."</td><td>".$row['empid']."</td>
        <td>".$row['dept']."</td>
        <td>".$row['cdate']."</td>
        <td>".$row['udate']."</td>
        <td style='text-align: center;'>".$duration."</td>
        <td style='color: green; text-align: center;'>".$row['archived']."</td>
        <td>
        <a href='view_empinfo.php?id=".$row['id']."' class='btn btn-primary btn-sm' id='btn'>VIEW</a>
        &nbsp;<a href='arch.php?' class='btn btn-danger btn-sm' id='btn' onclick=\"confirmDelete(event, ".$row['empid'].", '".$row['fname']."');\">ARCHIVE</a></td></tr>";              
    }
} else {
    $data = "<tr><td colspan='9' style='text-align:center;'>No records found.</td></tr>";
}

echo $data;
?>
