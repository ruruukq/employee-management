<?php 

session_start();

$conn = mysqli_connect('localhost','root','','emp_db');

if($conn){
 
} else {
    die(mysqli_error($con));
}

?>