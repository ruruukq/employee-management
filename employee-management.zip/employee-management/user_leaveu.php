<?php 
include 'dbconnection.php';

$row = [];

if(isset($_GET["empid"])){
    $empid = $_GET['empid'];

    $sql_employee = "SELECT * FROM register WHERE empid = '$empid'";
    $result_employee = $conn->query($sql_employee); 

    if (!$result_employee) {
        die("Error executing the query: " . $conn->error);
    }

    if ($result_employee->num_rows > 0) {
        $row = $result_employee->fetch_assoc();
    } else {
        echo "No matching record found for employee ID: $empid";
    }
}
if(isset($_GET['id'])){
    $id = $_GET['id'];
    
    if(isset($_GET['empid'])) {
        $empid = $_GET['empid'];
    } else {
        die("Employee ID not provided.");
    }

    $sql_leave = "SELECT * FROM leave_notice WHERE id = '$id'";
    $leave_result = $conn->query($sql_leave); 

    if (!$leave_result) {
        die("Error executing the query: " . $conn->error);
    }
}
if ($leave_result->num_rows > 0) {
    $leave_row = $leave_result->fetch_assoc();
} else {

    $leave_row = ['ltype' => '', 'msg' => '', 'fromd' => '', 'tod' => ''];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png">
    <link rel="stylesheet" href="css/reg.css">
    <title><?php echo isset($row['fname']) ? $row['fname'] : ''; ?></title>
</head>
<body>
  
<form action="user_leaveuf.php" method="POST">

<h1>EDIT LEAVE</h1>

<input type="hidden" name="id" value="<?php echo isset($leave_row['id']) ? $leave_row['id'] : ''; ?>">

<div class="col">
    <label>Employee's Fullname</label>
    <input type="text" class="form-control" id="fname" name="fname" value="<?php echo isset($row['fname']) ? $row['fname'] : ''; ?>" readonly style="font-size: 12px; font-family: 'Poppins';">
</div>

<div class="col">
    <label>Employee's ID</label>
    <input type="text" class="form-control" id="empid" name="empid" value="<?php echo isset($row['empid']) ? $row['empid'] : ''; ?>" readonly style="font-size: 12px; font-family: 'Poppins';">
</div>

<div class="col">
    <label>Leave Type</label>
    <select class="form-control" id="ltype" name="ltype" required="required" style="font-size: 12px; font-family: 'Poppins';">
        <option style="display: none;" disabled selected>Select Leave Type</option>
        <option value="Sick Leave" <?php if($leave_row['ltype'] == 'Sick Leave') echo 'selected'; ?>>Sick Leave</option>
        <option value="Annual Leave" <?php if($leave_row['ltype'] == 'Annual Leave') echo 'selected'; ?>>Annual Leave</option>
        <option value="Medical Leave" <?php if($leave_row['ltype'] == 'Medical Leave') echo 'selected'; ?>>Medical Leave</option>
        <option value="Paternity Leave" <?php if($leave_row['ltype'] == 'Paternity Leave') echo 'selected'; ?>>Paternity Leave</option>
        <option value="Maternity Leave" <?php if($leave_row['ltype'] == 'Maternity Leave') echo 'selected'; ?>>Maternity Leave</option>
        <option value="Maternity Leave" <?php if($leave_row['ltype'] == 'Vacation Leave') echo 'selected'; ?>>Vacation Leave</option>
        <option value="Religious Holidays" <?php if($leave_row['ltype'] == 'Religious Holidays') echo 'selected'; ?>>Religious Holidays</option>
    </select>
</div>


<div class="col">
    <label>Reason</label>
    <br>
    <textarea class="form-control" name="msg" id="msg" rows="3" required="required" style="font-size: 12px; font-family: 'Poppins';"><?php echo $leave_row['msg']; ?></textarea>
</div>

<br>

<div class="col">
  <label>Start Date :</label>
  <input type="date" class="form-control" name="fromd" id="fromd" value="<?php echo $leave_row['fromd']; ?>" style="font-size: 12px; font-family: 'Poppins';" required>
</div>

<br>

<div class="col">
  <label>End Date :</label>
  <input type="date" class="form-control" name="tod" id="tod" value="<?php echo $leave_row['tod']; ?>" style="font-size: 12px; font-family: 'Poppins';" required>
</div>
<br>

<div class="col">
        <label>Date Submitted :</label>
    <input class="form-control" value="<?php echo date('F j, Y');?>" readonly="readonly" style="font-size: 12px; font-family: 'Poppins';" name="tdate">
        </div>  

<div class="col">
    <br>
    <input type="submit" id="register" class="form-control" name="submit" value="EDIT">
</div>

<div class="row">
    <div class="col-lg-2">
        <br>
        <a class="btn btn-danger form-control" style="font-size: 12px; font-family: 'Poppins';" href="user_leaver.php?empid=<?php echo isset($row['empid']) ? $row['empid'] : ''; ?>">Cancel</a>
    </div>
</div>

</form>
</body>
</html>
