<?php

include 'dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["fname"])) {

    $fname = mysqli_real_escape_string($conn, $_GET['fname']);


    $sql = "SELECT empid FROM register WHERE fname = '$fname'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {

            $row = mysqli_fetch_assoc($result);
            $empid = $row['empid'];
            
            echo $empid;
        } else {

            echo "No matching record found for the provided employee name.";
        }
    } else {

        echo "Error: " . mysqli_error($conn);
    }
} else {

    echo "Invalid request.";
}
?>
