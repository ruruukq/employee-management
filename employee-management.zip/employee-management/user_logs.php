<?php 
include 'dbconnection.php';

$rows = [];

if(isset($_GET["empid"])){
    $id = $_GET['empid'];

    $sql = "SELECT u.empid,
            DATE_FORMAT(l.timelog, '%M %d, %Y at %l:%i %p') as formatted_date, 
            l.action_made 
            FROM logs l 
            INNER JOIN register u ON l.user_id = u.id 
            WHERE u.empid='$id'
            ORDER BY l.timelog ASC";

    $result = $conn->query($sql);

    if (!$result) {
        die("Error executing the query: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
    } else {
        echo "No matching record found for id: $id";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png">
    <link rel="stylesheet" href="css/admina1.css">
    <title>Activity Logs</title>
    <style>
        .table-container {
            width: 100%;
            overflow-x: auto;
        }
        .table {
            width: 100%;
            table-layout: auto;
        }
    </style>
</head>
<body>

<?php
include_once 'user_sidebar.php';
?>

<div class='main--content'>
    <div class='header--wrapper'>
        <div class='header--title'>
            <h4 style='font-family: Verdana; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;'>&nbsp;ACTIVITY LOGS</h4>
        </div>
    </div>
    <br><br><br>
    <div class='table-container'>
        <table class='table table-bordered'>
            <tr>
                <th style='text-align: center;'>Activity</th>
                <th style='text-align: center;'>Date and Time</th>
            </tr>
            <?php if (!empty($rows)): ?>
                <?php foreach ($rows as $row): ?>
                    <tr style='font-size: 15px;'>
                        <td style='text-align: center; font-style: italic; font-variant: oblique;'><?php echo htmlspecialchars($row['action_made']); ?></td>
                        <td style='text-align: center;'><?php echo htmlspecialchars($row['formatted_date']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="2" style='text-align: center;'>No records found.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>

    <div class="col-lg-2">
        <a class="btn btn-success form-control" style="font-size: 12px; font-family: 'Poppins';" id="editButton" href="userdash.php?empid=<?php echo isset($_GET['empid']) ? htmlspecialchars($_GET['empid']) : ''; ?>">BACK</a>
    </div>
</div>

</body>
</html>
