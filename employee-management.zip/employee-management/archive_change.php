<?php
if(isset($_GET['restid'])){
    $id = $_GET['restid'];

    $connect_db = new mysqli('localhost', 'root', '', 'emp_db');

    if ($connect_db->connect_error) {
        die("Connection failed: " . $connect_db->connect_error);
    }

    date_default_timezone_set('Asia/Manila');

    $user_id = 1;

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            echo "Error executing action_made statement: " . $stmt->error;
        }
        $stmt->close();
    }

    function fetchEmployeeName($conn, $id) {
        $stmt = $conn->prepare("SELECT fname FROM register WHERE empid=?");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $stmt->bind_result($fname);
        $stmt->fetch();
        $stmt->close();
        return $fname;
    }

    function restoreEmployee($conn, $id, $user_id) {
        $fname = fetchEmployeeName($conn, $id);
        
        if (empty($fname)) {
            die("Employee not found.");
        }

        $register_query = $conn->prepare("UPDATE register SET archived='On Duty' WHERE empid=?");
        $salary_query = $conn->prepare("UPDATE salary SET archived='On Duty' WHERE empid=?");
        $leave_query = $conn->prepare("UPDATE leave_notice SET archived='On Duty' WHERE empid=?");

        $register_query->bind_param("s", $id);
        $salary_query->bind_param("s", $id);
        $leave_query->bind_param("s", $id);

        $register_result = $register_query->execute();
        $salary_result = $salary_query->execute();
        $leave_result = $leave_query->execute();

        $register_query->close();
        $salary_query->close();
        $leave_query->close();

        if ($register_result && $salary_result && $leave_result) {
            action_made($conn, $user_id, "Restored $fname");
            echo "Employee restored successfully.";
        } else {
            die("Error restoring employee: " . $conn->error);
        }
    }

    restoreEmployee($connect_db, $id, $user_id);

    $connect_db->close();
}
?>
