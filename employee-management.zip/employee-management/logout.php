<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'dbconnection.php';

function action_made($conn, $user_id, $action_made, $user_status) {
    $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made, user_status) VALUES (?, NOW(), ?, ?)");
    $stmt->bind_param("iss", $user_id, $action_made, $user_status);
    if (!$stmt->execute()) {
        echo "Error executing action_made statement: " . $stmt->error;
    }
    $stmt->close();
}
$user_id = $_SESSION["user_id"];

$update_status_stmt = $conn->prepare("UPDATE register SET user_status='Offline' WHERE id=?");
$update_status_stmt->bind_param("i", $user_id);
$update_status_stmt->execute();
$update_status_stmt->close();

action_made($conn, $user_id, "Logged out from the system.", "Offline");

$latest_log_query = "SELECT MAX(timelog) as latest_date FROM logs WHERE user_id=?";
$latest_log_stmt = $conn->prepare($latest_log_query);
$latest_log_stmt->bind_param("i", $user_id);
$latest_log_stmt->execute();
$latest_log_result = $latest_log_stmt->get_result();

if ($latest_log_result && $latest_log_result->num_rows > 0) {
    $latest_log_row = $latest_log_result->fetch_assoc();
    $latest_date = $latest_log_row['latest_date'];

    $logs_query = "UPDATE logs SET user_status='Offline' WHERE user_id=? AND timelog=?";
    $logs_stmt = $conn->prepare($logs_query);
    $logs_stmt->bind_param("is", $user_id, $latest_date);
    if (!$logs_stmt->execute()) {
        echo "Error updating logs user status: " . $logs_stmt->error;
    }
    $logs_stmt->close();
}
$latest_log_stmt->close();

session_unset();
session_destroy();

header("Location: login.php");
exit();
?>
