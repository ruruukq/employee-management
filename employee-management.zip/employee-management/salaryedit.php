<?php
include 'dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $empid = $_POST['empid'];
    $salary = str_replace(',', '', $_POST['salary']);
    $dss = isset($_POST['dss']) ? (float) str_replace(',', '', $_POST['dss']) : 0;
    $ph = isset($_POST['ph']) ? (float) str_replace(',', '', $_POST['ph']) : 0;
    $pagibig = isset($_POST['pagibig']) ? (float) str_replace(',', '', $_POST['pagibig']) : 0;
    $tax = isset($_POST['tax']) ? (float) str_replace(',', '', $_POST['tax']) : 0;
    $udatee = $_POST['udatee'];
    $totalDeduction = array_sum([$dss, $ph, $pagibig, $tax]);

    $tsalary = $salary - $totalDeduction;

    $stmt = $conn->prepare("UPDATE `salary` SET fname=?, empid=?, salary=?, dss=?, ph=?, pagibig=?, tax=?, deduct=?, udatee=?, tsalary=? WHERE id=?");
    $stmt->bind_param("ssssssssssi", $fname, $empid, $salary, $dss, $ph, $pagibig, $tax, $totalDeduction, $udatee, $tsalary, $id);
    $stmt->execute();

    $user_id = 1;

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            echo "Error executing action_made statement: " . $stmt->error;
        }
        $stmt->close();
    }

    function fetchEmployeeName($conn, $empid) {
        $stmt = $conn->prepare("SELECT fname FROM register WHERE empid=?");
        $stmt->bind_param("s", $empid);
        $stmt->execute();
        $stmt->bind_result($fname);
        $stmt->fetch();
        $stmt->close();
        return $fname;
    }

    function editSalary($conn, $stmt, $id, $user_id, $fname, $empid, $salary, $dss, $ph, $pagibig, $tax, $totalDeduction, $udatee, $tsalary){
        $current_fname = fetchEmployeeName($conn, $empid);
        
        if (empty($current_fname)) {
            die("Employee not found.");
        }

        if ($stmt->affected_rows > 0) {
            session_start();
            action_made($conn, $user_id, "Updated $fname's Salary");
            $_SESSION['status'] = "SALARY UPDATED SUCCESSFULLY!";
            header("Location: salary_slip.php?id=$id");
            exit();
        } else {
            $_SESSION['message'] = "NOT UPDATED";
            header("Location: salary_slip.php?empid=$empid");
            exit();
        }
    }
    editSalary($conn, $stmt, $id, $user_id, $fname, $empid, $salary, $dss, $ph, $pagibig, $tax, $totalDeduction, $udatee, $tsalary);
}
?>
