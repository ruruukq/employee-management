<?php 
include 'dbconnection.php';

if(isset($_GET["id"])){
    $id = $_GET['id'];

    $sql = "SELECT * FROM `salary` WHERE `id` = '$id'";

    $result = $conn->query($sql);

    if($result->num_rows > 0){ 
        $row = $result->fetch_assoc();
        $fname = $row['fname'];
        $empid = $row['empid'];
        $salary = str_replace(',', '', $row['salary']);
        $ph = str_replace(',', '', $row['ph']);
        $dss = str_replace(',', '', $row['dss']);
        $pagibig = str_replace(',', '', $row['pagibig']);
        $tax = str_replace(',', '', $row['tax']);
        $deduct = str_replace(',', '', $row['deduct']);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png">
    <link rel="stylesheet" href="css/edit.css">
    <title>ADMIN - <?php echo $fname; ?></title>
</head>
<body>
<!----------------------------------EDIT------------------------------------------>
  <div class="modal fade" id="eModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header" style="background: #137d74; color: #fff;">
        <h1 class="modal-title fs-5" id="exampleModalLabel">EDIT SALARY</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="salaryedit.php" method="POST">
        <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
          <input type="hidden" id="id" name="id" value="<?php echo $id; ?>">
        
          <div class="col">
            <label>Employee's Fullname</label>
            <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $fname; ?>" placeholder="Enter Employee's Fullname" readonly style="font-size: 12px; font-family: 'Poppins';">
          </div>

          <div class="col">
            <label>Employee's ID</label>
            <input type="number" class="form-control" id="empid" name="empid" value="<?php echo $empid; ?>" placeholder="Enter Employee's ID"  readonly style="font-size: 12px; font-family: 'Poppins';">
          </div>

          <div class="col">
            <label>SALARY</label>
            <input type="text" class="form-control" id="salary" name="salary" value="<?php echo number_format($salary); ?>" placeholder="Enter Employee's Salary" required="required" style="font-size: 12px; font-family: 'Poppins';">
          </div>

    <div class="col">
            <label>Philhealth</label>
            <div id="phContainer">
            <input type="text" class="form-control" name="ph" id="ph" value="<?php echo number_format($ph); ?>" placeholder="no data." style="font-size: 12px;">
            </div>
    </div>

    <div class="col">
            <label>SSS</label>
            <div id="SSSContainer">
            <input type="text" class="form-control" name="dss" id="dss" value="<?php echo number_format($dss); ?>" placeholder="no data." style="font-size: 12px;">
            </div>
    </div>

    <div class="col">
            <label>Pagibig</label>
            <div id="pagibigContainer">
            <input type="text" class="form-control" name="pagibig" id="pagibig" value="<?php echo number_format($pagibig); ?>" placeholder="no data." style="font-size: 12px;">
            </div>
    </div>

    <div class="col">
            <label>Tax</label>
            <div id="taxContainer">
            <input type="text" class="form-control" name="tax" id="tax" value="<?php echo number_format($tax); ?>" placeholder="no data." style="font-size: 12px;">
            </div>
    </div>

          <div class="col">
            <label>Last Updated</label>
            <input class="form-control" value="<?php echo date('F j, Y');?>" readonly="readonly" id="udatee" name="udatee" style="font-size: 12px; font-family: 'Poppins';">
          </div>
        </div>
        
        <div class="modal-footer">
          <button type="submit" class="btn btn-lg" id="register">Edit</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!------------------------------------------------------------------------------->
<!----------------------------------EDIT NOTIF----------------------------------->
  <div class="row">
    <div class="col">
    <?php
    if(isset($_SESSION['status'])){
?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4><?php echo $_SESSION['status']; ?></h4>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['status']);
    }
?>
    </div>
        
</div> 
<!------------------------------------------------------------------------------->
<!----------------------------------VIEW----------------------------------------->
<form action="" method="POST" id="form" style="background-color: #fff;">
    <div class="main--content">
        <div class="header--wrapper">
            <div class="header--title">
                <h4 style="font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 50px;"><?php echo isset($fname) ? $fname."'s Salary Slip" : "Employee's Salary Slip"; ?></h4><br>
            </div>
        <br>
        <h6>Employee's ID : <?php echo isset($row['empid']) ? $row['empid'] : ''; ?></h6>
        <h6>Date Created : <?php echo isset($row['datee']) ? $row['datee'] : ''; ?></h6><br>
        
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Salary</th>
                        <th>Deductive Reason</th>
                        <th>Amount</th>
                        <th>Total Salary</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($result as $row): ?>
                        <tr>
                            <td>₱<?php echo number_format($row['salary']); ?></td>
                            <td>
                                <?php if ($row['ph']): ?>Philhealth<br><?php endif; ?>
                                <?php if ($row['dss']): ?>SSS<br><?php endif; ?>
                                <?php if ($row['pagibig']): ?>Pagibig<br><?php endif; ?>
                                <?php if ($row['tax']): ?>Tax<br><?php endif; ?>
                            </td>
                            <td>
                                <?php if ($row['ph']): ?>₱<?php echo number_format($row['ph']); ?><br><?php endif; ?>
                                <?php if ($row['dss']): ?>₱<?php echo number_format($row['dss']); ?><br><?php endif; ?>
                                <?php if ($row['pagibig']): ?>₱<?php echo number_format($row['pagibig']); ?><br><?php endif; ?>
                                <?php if ($row['tax']): ?>₱<?php echo number_format($row['tax']); ?><br><?php endif; ?>
                                <hr style="border: 2px solid; color: #000; border-radius: 5px;">
                                <?php if ($row['deduct']): ?>Total Deduction : ₱<?php echo number_format($row['deduct']); ?><br><?php endif; ?>
                            </td>
                            <td>₱<?php echo number_format($row['tsalary']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="row">
        <div class="col">
            <br><br>
            <hr style="border: 2px solid; color: #000; border-radius: 5px; width: 300px;">
            <p>Employee's signature over printed name</p>
        </div>
        <div class="col-lg-5">
            <br><br>
            <hr style="border: 2px solid; color: #000; border-radius: 5px; width: 300px;">
            <p>HR signature over printed name</p>
        </div>
    </div>
</form>

<!----------------------------------------------------------------------------->
<div class="row">
    <div class="col-lg-2">
        <a class="btn btn-primary form-control" id="register" style="font-size: 12px;" href="salaryview.php?empid=<?php echo $row['empid']; ?>">BACK</a>
    </div>
    <div class="col"></div>
    <div class="col-lg-2">    
        <button type="button" class="btn btn-primary form-control" id="register" style="font-size: 12px;" data-bs-toggle="modal" data-bs-target="#eModal">EDIT</button>
    </div>
</div>
</body>
</html>
