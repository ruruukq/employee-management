
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <link rel="icon" href="image/e3.png"> 
    <link rel="stylesheet" href="css/loginnn1.css">
    <title>LOGIN</title>
</head>
<body>

<?php

include 'dbconnection.php';
 
    if(isset($_SESSION['status'])){
?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-20 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4><?php echo $_SESSION['status']; ?></h4>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['status']);
    }
?>
<?php
    if(isset($_SESSION['invalid'])){
?>
    <div class="alert alert-danger alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4 class="alert-heading"><?php echo $_SESSION['invalid']; ?></h4>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['invalid']);
    }
?>

<?php
    if(isset($_SESSION['invalid1'])){
?>
    <div class="alert alert-danger alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4 class="alert-heading" style="text-align: center;">
  <?php echo $_SESSION['invalid1']; ?> Learn more <a href="learnmore.php" class="alert-link">here</a></h4>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['invalid1']);
    }
?>

 <?php
    if(isset($_SESSION['istatus'])){
?>
    <div class="alert alert-danger alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4 class="alert-heading"><?php echo $_SESSION['istatus']; ?></h4>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['istatus']);
    }
?>
    <img src="image/bg1.png" id="imge">
  
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
  <path fill="#fff" fill-opacity="1" d="M0,192L80,192C160,192,320,192,480,160C640,128,800,64,960,37.3C1120,11,1280,21,1360,26.7L1440,32L1440,320L1360,320C1280,320,1120,320,960,320C800,320,640,320,480,320C320,320,160,320,80,320L0,320Z"></path>
</svg>


<!-----------------------------------LOGIN---------------------------------------------->
<form action="login_function.php" id="form" method="POST">
<div class="wave">
  <div class="col-lg-12">
    <h1>LOGIN YOUR ACCOUNT</h1>
    <p>If you still don't have an account, you can <a href="register.php" id="reg">Register</a>&nbsp;for a better experience to manage your own account.</p>
            </div>
            </div>
    <i class="fas fa-envelope" style="color: #000;"></i>
    <label for="email" class="form-label">Email</label>
    <input type="email" class="form-control" name="email" id="email" aria-describedby="emailHelp" required>
  </div>
  <br>

  <div class="col-lg-12">
  <i class="fas fa-lock" style="color: #000;"></i>
    <label class="form-label">Password</label>
    <div class="input-group">
      <input type="password" class="form-control" name="pass" id="pass">
      <button class="btn btn-outline-secondary" type="button" id="togglePassword"><i class="fas fa-eye" style="color: #000"></i></button>
    </div>
  </div>
    </div>

  <a href="forgot/forgotpassword.php" id="forgot">Forgot Password?</a>
  <div class="col">
    <br>
          <input type="submit" id="submit" class="form-control" name="submit" value="Login">
</div>
<br>
<div class="row">
              <div class="col-lg-2">
                
            <a class="btn btn-primary form-control" id="submit" href="index.php">back</a>
            </div>
                      </div>
</form>

<script>
  document.getElementById('togglePassword').addEventListener('click', function() {
    const passwordInput = document.getElementById('pass');
    const button = document.getElementById('togglePassword');
    
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      button.innerHTML = '<i class="fas fa-eye" style="color: #000"></i>';
    } else {
      passwordInput.type = 'password';
      button.innerHTML = '<i class="fas fa-eye-slash" style="color: #000"></i>';
    }
  });
</script>


<!------------------------------------------------------------------------------------------>
</body>
</html>