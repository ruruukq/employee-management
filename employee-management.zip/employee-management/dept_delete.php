<?php

include 'dbconnection.php';

session_start(); 

if (isset($_GET['deleteid'])) {
    $ID = $_GET['deleteid'];
    $user_id = 1;

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            echo "Error executing action_made statement: " . $stmt->error;
        }
        $stmt->close();
    }

    function fetchDepartmentDetails($conn, $departmentId) {
        $stmt = $conn->prepare("SELECT dfull FROM department WHERE id = ?");
        $stmt->bind_param("i", $departmentId);
        $stmt->execute();
        $stmt->bind_result($dfull);
        $stmt->fetch();
        $stmt->close();
        return $dfull;
    }

    function deleteDept($conn, $ID, $user_id) {
        $dfull = fetchDepartmentDetails($conn, $ID);

        if (empty($dfull)) {
            die("Department not found.");
        }

        $sql = "DELETE FROM `department` WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $ID);
        $result = $stmt->execute();

        if ($result) {
            action_made($conn, $user_id, "Deleted $dfull");
            header('Location: dept_manage.php');
            exit();
        } else {
            $_SESSION['error'] = "Error deleting $dfull: " . $conn->error;
            header('Location: dept_manage.php');
            exit();
        }
    }
    deleteDept($conn, $ID, $user_id);
}
?>
