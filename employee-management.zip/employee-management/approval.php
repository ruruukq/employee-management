<?php
include 'dbconnection.php';

if(isset($_GET['approval'])){
    $leave_id = $_GET['approval']; 
    $user_id = 1;
    
    $query = "SELECT empid FROM leave_notice WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $leave_id);
    $stmt->execute();
    $stmt->bind_result($empid);
    $stmt->fetch();
    $stmt->close();
    
    if(empty($empid)){
        die("Employee not found.");
    }

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            echo "Error executing action_made statement: " . $stmt->error;
        }
        $stmt->close();
    }

    function rejectLeave($conn, $leave_id, $user_id, $empid) {
        $query = "SELECT fname FROM register WHERE empid = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $empid);
        $stmt->execute();
        $stmt->bind_result($fname);
        $stmt->fetch();
        $stmt->close();
        
        if(empty($fname)){
            die("Employee not found.");
        }
        
        $query = "UPDATE leave_notice SET apprv='APPROVED' WHERE id=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $leave_id);
        $result = $stmt->execute();
        
        if($result){
            action_made($conn, $user_id, "Approved $fname's Leave");
            echo "<script>window.location.href = 'leave_approve.php'</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    }
    
    rejectLeave($conn, $leave_id, $user_id, $empid);
}
?>
