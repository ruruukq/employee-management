<?php 

$con = new mysqli ('localhost','root','','emp_db');

if(!$con){
    die(mysqli_error($con));
}

?>