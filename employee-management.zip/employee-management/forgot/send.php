<?php
require("connection.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

function sendMail($email, $reset_token){
    
    $mail = new PHPMailer(true);
    
    $mail->isSMTP();
    $mail->Host =  'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'employeesystem3@gmail.com';
    $mail->Password = 'zosbxtpxqlayglcc';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;

    $mail->setFrom('employeesystem3@gmail.com'); 

    $mail->addAddress($_POST["email"]);

    $mail->isHTML(true);

    $mail->Subject = 'WELCOME TO EMPLOYEE SYSTEM';
    $mail->Body = "This email will allow you to change your registered password.<br>
    Click the link below to reset your password <br>
    <a href='http://localhost/employee-management/forgot/newpassword.php?email=$email&reset_token=$reset_token' class='btn btn-success'>RESET PASSWORD</a>
    ";
    
    try {
        $mail->send();
        echo "
        <script>
        alert('Link Sent Successfully');
        document.location.href = '/employee-management/login.php';
        </script>
        ";
    } catch (Exception $e) {
        echo "
        <script>
        alert('Failed to send email. Please check your internet connection.');
        document.location.href = '/employee-management/login.php';
        </script>
        ";
    }
}

if(isset($_POST['link-email'])){
    $query = "SELECT * FROM `register` WHERE `email` = '$_POST[email]'";
    $result = mysqli_query($con, $query);

    if($result)
    {
        if(mysqli_num_rows($result)==1)
        {
            $reset_token = bin2hex(random_bytes(16));
            date_default_timezone_set(('Asia/kolkata'));
            $date = date ("Y-m-d");
            $query = "UPDATE `register` SET `resettoken` = '$reset_token', `resettokenexpire` = '$date' WHERE `email` = '$_POST[email]'";
            if(mysqli_query($con,$query))
            {

                sendMail($_POST['email'],$reset_token);
            }
            else{
                echo "
                <script>
                alert('Server down! try again later');
                document.location.href = '/employee-management/login.php';
                </script>
                ";
            }
        }
        else{
            echo "
            <script>
            alert('OOPS! Email Not Found');
            document.location.href = '/employee-management/forgot/forgotpassword.php';
            </script>
            ";
        }
    }
    else{
        echo "
        <script>
        alert('Cannot run query');
        document.location.href = '/employee-management/login.php';
        </script>
        ";
    }
}
?>
