<?php
require("connection.php");

if (isset($_POST['pass'])) {
    $pass = $_POST['pass'];
    
    $email = $_GET['email'];
    
    $getUserIDQuery = "SELECT `id` FROM `register` WHERE `email`='$email'";
    $result = mysqli_query($con, $getUserIDQuery);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $id = $row['id'];

        $updatePasswordQuery = "UPDATE `register` SET `pass`='$pass', `resettoken`=NULL, `resettokenexpire`=NULL WHERE `id`='$id'";
        if (mysqli_query($con, $updatePasswordQuery)) {
            echo "<script>
                alert('Password updated successfully');
                window.location.href='/employee-management/login.php';
                </script>";
        } else {
            echo "<script>
                alert('Failed to update the password');
                </script>";
        }
    } else {
        echo "<script>
            alert('Invalid email');
            </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
  <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
  <link rel="stylesheet" href="forgot5.css">
  <link rel="icon" href="../image/e3.png">
  <title>Create New Password</title>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
  <path fill="#fff" fill-opacity="1" d="M0,192L80,202.7C160,213,320,235,480,240C640,245,800,235,960,240C1120,245,1280,267,1360,277.3L1440,288L1440,320L1360,320C1280,320,1120,320,960,320C800,320,640,320,480,320C320,320,160,320,80,320L0,320Z"></path>
</svg>
<form action="" method="POST"><br>
<h3>NEW PASSWORD</h3>

<div class="col-lg-12">
  <i class="fas fa-lock" style="color: #000;"></i>
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <div class="input-group">
      <input type="password" class="form-control" name="pass" id="pass" placeholder="Enter new password">
      <button class="btn btn-outline-secondary" type="button" id="togglePassword"><i class="fas fa-eye" style="color: #000"></i></button>
    </div>
  </div>
    </div>
    <br>
<div class="col">
                <button type="submit" id="submit" name="link-email" class="form-control">Submit</button>
                </div>
  <br>

                <div class="col-lg-4">
                <a href="/employee-management/login.php" class='btn btn-danger form-control'>Cancel</a>
                </div>
</form>

<script>
  document.getElementById('togglePassword').addEventListener('click', function() {
    const passwordInput = document.getElementById('pass');
    const button = document.getElementById('togglePassword');
    
    if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      button.innerHTML = '<i class="fas fa-eye" style="color: #000"></i>';
    } else {
      passwordInput.type = 'password';
      button.innerHTML = '<i class="fas fa-eye-slash" style="color: #000"></i>';
    }
  });
</script>
</body>
</html>