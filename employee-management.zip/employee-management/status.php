<?php
 
if(isset($_GET['ustats'])){
    $id=$_GET['ustats'];
    $connect_db = new mysqli('localhost','root','','emp_db');
    $query = "UPDATE leave_notice SET id='$id', user_status='Online' WHERE id='$id' ";
   
    $result = $connect_db->query($query);

    if($result){
        echo "<script>window.location.href = 'leave_approve.php'</script>";
    }else{
        die(mysqli_error($con));
    }

}
?>