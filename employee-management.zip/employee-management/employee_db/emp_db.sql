-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2024 at 03:21 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `dfull` varchar(250) NOT NULL,
  `cdate` varchar(250) NOT NULL,
  `edate` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `dfull`, `cdate`, `edate`) VALUES
(28, 'IT DEPARTMENT', 'May 13, 2024', ''),
(31, 'HR DEPARTMENT', 'May 25, 2024', ''),
(32, 'EDUC DEPARTMENT', 'May 27, 2024', ''),
(41, 'CS DEPARTMENT', 'May 27, 2024', 'May 27, 2024'),
(47, 'CBA DEPARTMENT', 'May 27, 2024', ''),
(49, 'CRIM DEPARTMENT', 'May 31, 2024', 'May 31, 2024');

-- --------------------------------------------------------

--
-- Table structure for table `leave_notice`
--

CREATE TABLE `leave_notice` (
  `id` int(11) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `empid` varchar(250) NOT NULL,
  `ltype` varchar(250) NOT NULL,
  `msg` varchar(250) NOT NULL,
  `fromd` varchar(250) NOT NULL,
  `tod` varchar(250) NOT NULL,
  `tdate` varchar(250) NOT NULL,
  `apprv` text NOT NULL,
  `archived` varchar(250) NOT NULL,
  `archive_date` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `leave_notice`
--

INSERT INTO `leave_notice` (`id`, `fname`, `empid`, `ltype`, `msg`, `fromd`, `tod`, `tdate`, `apprv`, `archived`, `archive_date`) VALUES
(678137, 'William Daniel', '678070', 'Vacation Leave', 'Lorem ipsum dolor sit amet. Qui cumque harum aut dolores fuga vel temporibus quibusdam aut omnis magni et nobis dolorem aut quia quae. Et repellendus rerum est delectus adipisci hic dicta nemo et maiores quidem sit nulla sint sed voluptatem omnis est', '2024-06-07', '2024-06-12', 'May 30, 2024', 'APPROVED', 'On Duty', 'May 31, 2024 at 8:21 am<br>Friday'),
(678138, 'Charlotte Dior', '123456', 'Vacation Leave', 'Lorem ipsum dolor sit amet. Eos dolorum velit sed laboriosam quas quo aperiam consequatur. In enim voluptatem sit galisum quibusdam aut rerum tempora et nisi aperiam. Qui laudantium doloremque a laboriosam vitae et facere minus non praesentium.', '2024-06-12', '2024-06-15', 'May 31, 2024', 'CANCELED', 'On Duty', '');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(30) NOT NULL,
  `action_made` varchar(255) NOT NULL,
  `timelog` datetime NOT NULL,
  `user_status` varchar(250) NOT NULL,
  `empid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `action_made`, `timelog`, `user_status`, `empid`) VALUES
(381, 1, 'Has logged in to the system', '2024-05-30 10:18:20', 'Online', 0),
(383, 1, 'Archived Elijah Cord', '2024-05-30 10:21:26', '', 0),
(384, 1, 'Added William Daniel\'s Salary', '2024-05-30 10:23:12', '', 0),
(385, 1, 'Added Charlotte Diore\'s Salary', '2024-05-30 10:23:58', '', 0),
(388, 58, 'Has logged in to the system', '2024-05-30 10:31:15', 'Online', 0),
(390, 58, 'Logged out from the system.', '2024-05-30 10:37:12', 'Offline', 0),
(391, 36, 'Has logged in to the system', '2024-05-30 10:38:10', 'Online', 0),
(396, 36, 'Request for a Vacation Leave', '2024-05-30 10:49:43', '', 0),
(397, 36, 'Logged out from the system.', '2024-05-30 10:52:04', 'Offline', 0),
(398, 36, 'Has logged in to the system', '2024-05-30 11:02:34', 'Online', 0),
(399, 36, 'Logged out from the system.', '2024-05-30 11:03:39', 'Offline', 0),
(400, 1, 'Logged out from the system.', '2024-05-30 10:30:45', 'Offline', 0),
(401, 1, 'Has logged in to the system', '2024-05-31 07:40:56', 'Online', 0),
(402, 1, 'Added CRIM DEPARTMENT', '2024-05-31 07:41:20', '', 0),
(403, 1, 'Updated CRIM DEPARTMENTt', '2024-05-31 07:43:11', '', 0),
(404, 1, 'Updated CRIM DEPARTMENT', '2024-05-31 07:43:22', '', 0),
(405, 1, 'Updated CRIM DEPARTMENT', '2024-05-31 07:43:32', '', 0),
(406, 1, 'Added CRIM DEPARTMENTt', '2024-05-31 07:43:37', '', 0),
(407, 1, 'Deleted CRIM DEPARTMENTt', '2024-05-31 07:43:48', '', 0),
(412, 58, 'Has logged in to the system', '2024-05-31 07:48:40', 'Online', 0),
(413, 58, 'Request for a Vacation Leave', '2024-05-31 07:49:34', '', 0),
(414, 1, 'Updated Charlotte Dior\'s Information', '2024-05-31 07:50:26', '', 0),
(415, 1, 'Updated Noah Adam\'s Information', '2024-05-31 07:51:49', '', 0),
(419, 1, 'Updated William Danie\'s Information', '2024-05-31 08:18:47', '', 0),
(420, 1, 'Updated William Daniel\'s Information', '2024-05-31 08:19:06', '', 0),
(457, 1, 'Has logged in to the system', '2024-05-31 09:21:33', 'Online', 0),
(458, 1, 'Logged out from the system.', '2024-05-31 09:21:39', 'Offline', 0);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(250) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `empid` varchar(250) NOT NULL,
  `dept` varchar(250) NOT NULL,
  `contact` varchar(250) NOT NULL,
  `bdate` varchar(250) NOT NULL,
  `mstats` varchar(250) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `addrss` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `pass` varchar(250) NOT NULL,
  `resettoken` varchar(250) NOT NULL,
  `resettokenexpire` varchar(250) NOT NULL,
  `usertype` text NOT NULL,
  `cdate` varchar(250) NOT NULL,
  `udate` varchar(250) NOT NULL,
  `scl` varchar(250) NOT NULL,
  `deg` varchar(250) NOT NULL,
  `skills` varchar(250) NOT NULL,
  `cred` varchar(250) NOT NULL,
  `adminid` varchar(250) NOT NULL,
  `img` varchar(250) NOT NULL,
  `archived` varchar(250) NOT NULL,
  `archive_date` varchar(250) NOT NULL,
  `user_status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fname`, `empid`, `dept`, `contact`, `bdate`, `mstats`, `gender`, `addrss`, `email`, `pass`, `resettoken`, `resettokenexpire`, `usertype`, `cdate`, `udate`, `scl`, `deg`, `skills`, `cred`, `adminid`, `img`, `archived`, `archive_date`, `user_status`) VALUES
(1, 'Administrator', '', 'HR DEPARTMENT', '', '', '', '', '', 'admin@gmail.com', 'admin123', '', '', 'ADMIN', '0000-00-00 00:00:00', 'May 24, 2024', '', '', '', '', '123', '', 'On Duty', '', 'Offline'),
(35, 'Noah Adam', '342412', 'IT DEPARTMENT', '09786546271', '2002-08-15', 'Single', 'Male', 'Toledo, Ohio', 'noah123@gmail.com', '12345', '', '', 'USER', 'May 13, 2024', '', 'Oberlin College', 'Bachelor of Science in Computer Science', 'Creativity', 'none', '', 'Boy free icons designed by Creartive.jpg', 'On Duty', 'May 27, 2024 at 9:50 am<br>Monday', 'Offline'),
(36, 'William Daniel', '678070', 'CS DEPARTMENT', '09785634121', '1998-06-05', 'Single', 'Male', 'Sacramento, California USA', 'will@gmail.com', '12345', '', '', 'USER', 'May 13, 2024', '', 'Sacramento State University', 'Bachelor of Science in Computer Science', 'Web Developing', 'none', '', 'Download man with beard avatar character isolated icon for free.jpg', 'On Duty', 'May 31, 2024 at 8:21 am<br>Friday', 'Offline'),
(38, 'Elijah Cord', '234567', 'CS DEPARTMENT', '09346527182', '1995-12-05', 'Single', 'Male', 'Scottsdale, Arizona USA', 'elijah123@gmail.com', '12345', '', '', 'USER', 'May 23, 2024', '', 'Arizona State University Tempe Campus', 'BSCS', 'Creativity', 'None', '', 'Male avatar, portrait of a young man with a beard_ Vector illustration of male character in modern color style.jpg', 'INACTIVE', 'May 31, 2024 at 9:08 am<br>Friday', 'Offline'),
(58, 'Charlotte Dior', '123456', 'CS DEPARTMENT', '09212349836', '1999-05-13', 'Single', 'Female', 'Anchorage, Alaska', 'lotte@gmail.com', 'lotte123', '', '', 'USER', 'May 24, 2024', '', 'University of Alaska Anchorage', 'Bachelor of Science in Computer Science', 'Programming, Creativity', 'none', '', 'Premium Vector _ Portrait of a beautiful young woman.jpg', 'On Duty', 'May 27, 2024 at 4:41:03 am<br>Monday', 'Offline');

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` int(250) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `empid` varchar(250) NOT NULL,
  `salary` int(250) NOT NULL,
  `tsalary` varchar(250) NOT NULL,
  `deduct` int(250) NOT NULL,
  `dss` varchar(250) NOT NULL,
  `ph` varchar(250) NOT NULL,
  `pagibig` varchar(250) NOT NULL,
  `tax` varchar(250) NOT NULL,
  `datee` varchar(250) NOT NULL,
  `udatee` varchar(250) NOT NULL,
  `archived` varchar(250) NOT NULL,
  `archive_date` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `fname`, `empid`, `salary`, `tsalary`, `deduct`, `dss`, `ph`, `pagibig`, `tax`, `datee`, `udatee`, `archived`, `archive_date`) VALUES
(86, 'William Daniel', '678070', 50000, '45000', 5000, '5000', '0', '0', '0', 'May 30, 2024', '', 'On Duty', 'May 31, 2024 at 8:21 am<br>Friday'),
(87, 'Charlotte Dior', '123456', 100000, '90400', 9600, '2500', '2000', '100', '5000', 'May 30, 2024', 'May 31, 2024', 'On Duty', ''),
(89, 'Noah Adam', '342412', 35000, '31500', 3500, '500', '1500', '0', '1500', 'May 31, 2024', '', 'On Duty', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_notice`
--
ALTER TABLE `leave_notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `leave_notice`
--
ALTER TABLE `leave_notice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=678139;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=459;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
