<?php
include 'dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['fname'];
    $empid = $_POST['empid'];
    $ltype = $_POST['ltype'];
    $msg = $_POST['msg'];
    $fromd = $_POST['fromd'];
    $tod = $_POST['tod'];
    $tdate = $_POST['tdate'];
    $apprv = "PENDING";
    $useer = "On Duty";
    $user_id = $_SESSION['user_id'];

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            die("Error executing action_made statement: " . $stmt->error);
        }
        $stmt->close();
    }

    function applyLeave($conn, $fname, $empid, $ltype, $msg, $fromd, $tod, $tdate, $apprv, $user_id, $useer) {
        if (!preg_match("/^[a-zA-Z0-9\s!?,.\/():;\"']+$/", $msg)) {
            $_SESSION['istatus'] = "Invalid message format. Please enter a valid message.";
            header("Location: user_leaver.php?empid=" . $empid);
            exit();
        }
        $sql = "INSERT INTO leave_notice (fname, empid, ltype, msg, fromd, tod, tdate, apprv, archived) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssssss", $fname, $empid, $ltype, $msg, $fromd, $tod, $tdate, $apprv, $useer);

        if ($stmt->execute()) {
            action_made($conn, $user_id, "Request for a $ltype");
            $_SESSION['status'] = "LEAVE REQUEST SENT SUCCESSFULLY";
            header("Location: user_leaver.php?empid=" . $empid);
            exit();
        } else {
            die("Error executing SQL statement: " . $stmt->error);
        }
    }
    applyLeave($conn, $fname, $empid, $ltype, $msg, $fromd, $tod, $tdate, $apprv, $user_id, $useer);
}
?>
