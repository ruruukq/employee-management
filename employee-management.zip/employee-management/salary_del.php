<?php

include 'dbconnection.php';

if (isset($_GET['deleteid'])) {
    $ID = $_GET['deleteid'];
    $user_id = 1;

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            echo "Error executing action_made statement: " . $stmt->error;
        }
        $stmt->close();
    }

    function fetchEmployeeDetails($conn, $salaryId) {
        $stmt = $conn->prepare("SELECT r.fname, r.empid FROM register r JOIN salary s ON r.empid = s.empid WHERE s.id = ?");
        $stmt->bind_param("i", $salaryId);
        $stmt->execute();
        $stmt->bind_result($fname, $empid);
        $stmt->fetch();
        $stmt->close();
        return array($fname, $empid);
    }
    function deleteSalary($conn, $ID, $user_id) {
        list($fname, $empid) = fetchEmployeeDetails($conn, $ID);

        if (empty($fname)) {
            die("Employee not found.");
        }

        $sql = "DELETE FROM `salary` WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $ID);
        $result = $stmt->execute();

        if ($result) {
            action_made($conn, $user_id, "Deleted $fname's Salary");
            exit();
        } else {
            die($stmt->error);
        }
    }

    deleteSalary($conn, $ID, $user_id);
}
?>