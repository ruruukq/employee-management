<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="icon" href="image/e3.png"> 
    <link rel="stylesheet" href="css/admina1.css">
    <title>WELCOME ADMIN</title>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <form action="" method="POST">
    
    <div class="sidebar">
        <div class="logo"></div>
        <ul class="menu">
            <div class="admin">
                <img src="profile/admin.jpg" alt="image" class="rounded-circle" width='60px'>
                <span>Administrator</span>
            </div>
            <li>
                <a href="admin.php">
                    <i class="fa-solid fa-gauge"></i>
                    <span>&nbsp;Dashboard</span>
                </a>
            </li>
            <li>
                <a href="dept_manage.php">
                    <i class="fa-solid fa-building-user"></i>
                    <span>Manage&nbsp;Department</span>
                </a>
            </li> 
            <div class="dropdownmenu">
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link has-dropdown collapsed dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#emp" aria-expanded="false" aria-controls="emp" onclick="toggleDropdown('emp')">
                        <i class="fa-solid fa-users"></i>
                        <span>Manage<br>Employee</span>
                    </a>
                    <ul id="emp" class="sidebar-dropdown list-unstyled collapse" aria-labelledby="dropdownMenuButton" data-bs-parent=".sidebar">
                        <li class="sidebar-item">
                            <a href="view.php" class="sidebar-link"><i class="fa-solid fa-user"></i> View Employees</a>
                        </li>
                        <li class="sidebar-item">
                            <a href="salary.php" class="sidebar-link"><i class="fa-solid fa-dollar"></i>&nbsp;&nbsp;&nbsp;View Salary</a>
                        </li>
                        <li class="sidebar-item">
                            <a href="leave_manage.php" class="sidebar-link"><i class="fa-solid fa-message"></i>View Leave Requests</a>
                        </li>
                    </ul>
                </li>
            </div>
            <li class="logout">
                <a href="logout.php" style="font-size: 15px;" onclick="SweetAlert4(event)">
                    <i class="fa-solid fa-right-from-bracket"></i>Logout
                </a>
            </li>
        </ul>
    </div>
</form>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function SweetAlert4(event) {
    event.preventDefault();
    Swal.fire({
        title: 'Continue to Logout?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#135D66',
        confirmButtonText: 'Yes, Logout',
        cancelButtonColor: '#d33',
        cancelButtonText: 'No!'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'logout.php';
        }
    });
}

document.querySelectorAll('.sidebar-item').forEach(item => {
    const link = item.querySelector('.sidebar-link');
    const dropdown = item.querySelector('.sidebar-dropdown');

    link.addEventListener('click', () => {
        const isOpen = dropdown.classList.contains('show');
        document.querySelectorAll('.sidebar-dropdown').forEach(dropdown => {
            dropdown.classList.remove('show');
        });
        if (!isOpen) {
            dropdown.classList.add('show');
        }
    });

    item.addEventListener('mouseleave', () => {
        const isMouseOverLink = link.matches(':hover');
        const isMouseOverDropdown = dropdown.matches(':hover');
        if (!isMouseOverLink && !isMouseOverDropdown) {
            dropdown.classList.remove('show');
        }
    });
});

document.addEventListener('click', (event) => {
    const dropdowns = document.querySelectorAll('.sidebar-dropdown');
    dropdowns.forEach(dropdown => {
        const isClickInside = dropdown.contains(event.target);
        if (!isClickInside) {
            dropdown.classList.remove('show');
        }
    });
});
</script>
</body>
</html>
