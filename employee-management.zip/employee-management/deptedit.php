<?php
session_start();
include 'dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $dfull = $_POST['dfull'];
    $edate = $_POST['edate'];

    $id = mysqli_real_escape_string($conn, $id);
    $dfull = mysqli_real_escape_string($conn, $dfull);
    $edate = mysqli_real_escape_string($conn, $edate);

    $user_id = 1;

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            echo "Error executing action_made statement: " . $stmt->error;
        }
        $stmt->close();
    }

    $check_query = "SELECT * FROM department WHERE dfull='$dfull' AND id != '$id'";
    $check_result = $conn->query($check_query);

    if ($check_result === false) {
        echo "Error in check query: " . $conn->error;
    } else {
        if ($check_result->num_rows > 0) {
            $_SESSION['estatus'] = "EDIT FAILED! DEPARTMENT ALREADY EXISTS!";
            header('Location: dept_manage.php');
            exit(0);
        }
    }

    $query = "UPDATE department SET dfull='$dfull', edate='$edate' WHERE id='$id'";
    $result = $conn->query($query);
    if ($result) {
        action_made($conn, $user_id, "Updated $dfull");
        $_SESSION['status'] = "DEPARTMENT UPDATED SUCCESSFULLY";
        header('Location: dept_manage.php');
        exit(0);
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
