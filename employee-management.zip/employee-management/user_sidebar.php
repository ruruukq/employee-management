<?php
$servername = "localhost"; 
    $dbname = "emp_db"; 

    $conn = new mysqli($servername, "root", "", $dbname);

    $row = [];

    if(isset($_GET["empid"])){
        $id = $_GET['empid'];
    
        $sql = "SELECT * FROM `register` WHERE `empid` = '$id'";
    
        $result = $conn->query($sql);
    
        if (!$result) {
            die("Error executing the query: " . $conn->error);
        }
    
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $fname = $row['fname'];
        } else {
            echo "No matching record found for id: $id";
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e2.png"> 
    <link rel="stylesheet" href="css/admina1.css">
    <title><?php echo isset($row['fname']) ? $row['fname'] : 'User'; ?></title>
</head>
<body>

    <form action="user_func.php">
        <div class="sidebar">
            <div class="logo">
            </div>
            <ul class="menu">
                <div class="admin">
                    <img src="<?php 
                        $request_uri = explode("/",$_SERVER['REQUEST_URI']);
                        echo '//'.$_SERVER['HTTP_HOST'].'/'.$request_uri[1].'../profile/'.$row['img']; ?>" 
                        alt="image" class="rounded-circle" width='60px'>
                    <span><?php echo isset($row['fname']) ? $row['fname'] : "Unknown"; ?></span>
                </div>
                <li>
                    <a href="userdash.php?empid=<?php echo isset($row['empid']) ? $row['empid'] : ""; ?>" role="button">
                        <i class="fa-solid fa-dashboard"></i>
                        <span>Dashboard</span> 
                    </a>
                </li>
                <li>
                    <a href="user_info.php?empid=<?php echo isset($row['empid']) ? $row['empid'] : ""; ?>" role="button">
                        <i class="fa-solid fa-circle-info"></i>
                        <span>Information</span> 
                    </a>
                </li>
                <li>
                    <a href="user_salary.php?empid=<?php echo isset($row['empid']) ? $row['empid'] : ""; ?>" role="button">
                        <i class="fa-solid fa-dollar-sign"></i>
                        <span>&nbsp;&nbsp;&nbsp;Salary</span>
                    </a>
                </li>
                <li>
                    <a href="user_leaver.php?empid=<?php echo isset($row['empid']) ? $row['empid'] : ""; ?>" role="button">
                        <i class="fa-solid fa-message"></i>
                        <span>&nbsp;&nbsp;Leave Request</span>
                    </a>
                </li>
                <li class="logout">
                    <a href="logout.php" style="font-size: 15px;" onclick="SweetAlert4(event)">
                        <i class="fa-solid fa-right-from-bracket"></i>Logout
                    </a>
                </li>
            </ul>
        </div>
    </form>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    function SweetAlert4(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Continue to Logout?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#135D66',
            confirmButtonText: 'Yes, Logout',
            cancelButtonColor: '#d33',
            cancelButtonText: 'No!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'logout.php';
            }
        });
    }
    </script>
</body>
</html>
