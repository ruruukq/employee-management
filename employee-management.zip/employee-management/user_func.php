<?

$conn = mysqli_connect('localhost','root','','emp_db');

$id = $_GET['id'];
$query = "SELECT * FROM register where ID='$id'";
$query_run = mysqli_query($con, $query);

if(mysqli_num_rows($query_run) > 0)
{
  foreach($query_run as $row)
  {
    echo $row['id'];
  }
}
else {
  echo "No record available";
}
?>