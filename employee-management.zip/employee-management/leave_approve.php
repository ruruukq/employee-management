<?php
include_once 'dbconnection.php'; 

$page_no = isset($_GET['page_no']) && $_GET['page_no'] !== "" ? (int)$_GET['page_no'] : 1;
$total_records_per_page = 10;
$offset = ($page_no - 1) * $total_records_per_page;

$sql = "SELECT * FROM `leave_notice` 
WHERE `archived` = 'On Duty' AND `empid` IS NOT NULL AND `empid` <> '' 
AND apprv = 'APPROVED' ORDER BY id DESC
LIMIT $offset, $total_records_per_page";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Error: " . mysqli_error($conn));
}

$total_records_query = "SELECT COUNT(*) as total_records FROM `leave_notice` WHERE `empid` IS NOT NULL AND `empid` <> '' AND apprv = 'APPROVED'";
$total_records_result = mysqli_query($conn, $total_records_query);
$total_records = mysqli_fetch_assoc($total_records_result)['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
      <link rel="icon" href="image/e3.png">
      <link rel="stylesheet" href="css/view.css">
      <title>ADMIN - EMPLOYEE LEAVE</title>

</head>
<body>
<?php
include_once 'admin_sidebar.php';
?>
 <div class="main--content">
      <div class="header--wrapper">
        <div class="header--title">
          <h4 style="font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;">&nbsp;APPROVED LEAVE REQUESTS</h4>
</div>
  
  </div>

  <div class="row">
<div class="col"></div>
  
    <div class="col-lg-1">
    <div class="dropdown">
    <button class="btn btn-primary btn-sm dropdown-toggle" id="back" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false" style="position: absolute; right: 10px;">
        APPROVED
    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <li><a class="dropdown-item" href="leave_manage.php">ALL</a></li>
        <li><a class="dropdown-item" href="leave_approve.php">APPROVED</a></li>
        <li><a class="dropdown-item" href="leave_reject.php">REJECTED</a></li>
    </ul>
</div>
    </div>
    </div>
<br><br>
<div class="table-responsive">
    <table class="table table-bordered" id="tbl">
        <thead>
            <tr>
            <th style="text-align: center;">Employee's Fullname</th>
            <th style="text-align: center;">Leave Type</th>
                <th style="text-align: center;">Date Submitted</th>
                <th style="text-align: center;">Reason</th>
                <th style="text-align: center;">Start Date</th>
                <th style="text-align: center;">End Date</th>
                <th style="text-align: center;">Approval</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && mysqli_num_rows($result) > 0) : ?>
                <?php while ($rows = mysqli_fetch_assoc($result)) : ?>
                    <tr>
                    <td style="text-align: center; width: 150px;"><?php echo $rows['fname']; ?></td>
                    <td style="text-align: center;"><?php echo $rows['ltype']; ?></td>
                        <td style="text-align: center;"><?php echo $rows['tdate']; ?></td>
                        <td style="width: 200px;"><?php echo $rows['msg']; ?><br></td>
                        <td style="text-align: center; width: 100px;"><?php echo date('F j, Y', strtotime($rows['fromd'])); ?></td>
                        <td style="text-align: center;"><?php echo date('F j, Y', strtotime($rows['tod'])); ?></td>
                        <td style="text-align: center; font-family: verdana;" class="<?php echo getApprovalClass($rows['apprv']); ?>"><strong><?php echo $rows['apprv']; ?></strong></td>
                    </tr>
                <?php endwhile; ?>
            <?php else : ?>
                <tr>
                    <td colspan="10" style="text-align: center;">No leave records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

    <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item <?php echo $page_no <= 1 ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page_no=<?php echo $page_no - 1; ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_no_of_pages; $i++) : ?>
                    <li class="page-item <?php echo $page_no == $i ? 'active' : ''; ?>">
                        <a class="page-link" href="?page_no=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?php echo $page_no >= $total_no_of_pages ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page_no=<?php echo $page_no + 1; ?>">Next</a>
                </li>
            </ul>
                </nav>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    function SweetAlert1(event, id) {
        event.preventDefault();
        Swal.fire({
            title:  'You are going to Approve this leave. Continue?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#135D66',
            confirmButtonText: 'Yes, Approve Leave',
            cancelButtonColor: '#d33',
            cancelButtonText: 'Cancel!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'approval.php?approval=' + id;
            }
        });
    }
</script>

<script>
    function SweetAlert2(event, id) {
        event.preventDefault();
        Swal.fire({
            title: 'You are going to Reject this leave. Continue?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#135D66',
            confirmButtonText: 'Yes, Reject Leave',
            cancelButtonColor: '#d33',
            cancelButtonText: 'Cancel!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'disapproved.php?dappr=' + id;
            }
        });
    }
</script>
<script>
    function SweetAlert3(event, id) {
        event.preventDefault();
        Swal.fire({
            title: 'You are going to Disable this leave. Continue?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#135D66',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Disable Leave',
            cancelButtonText: 'Cancel!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'approval_change.php?appr=' + id;
            }
        });
    }
</script>

<?php
function getApprovalClass($status) {
    switch ($status) {
        case 'APPROVED':
            return 'text-success';
        case 'REJECTED':
        case 'CANCELLED':
        case 'DISABLED':
            return 'text-danger';
        default:
            return 'text-primary';
}
}
?>
</body>
</html>