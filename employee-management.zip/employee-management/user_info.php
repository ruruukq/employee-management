<?php 
include 'dbconnection.php';

$row = [];

if(isset($_GET["empid"])){
    $id = $_GET['empid'];

    $sql = "SELECT * FROM `register` WHERE `empid` = '$id'";

    $result = $conn->query($sql);

    if (!$result) {
        die("Error executing the query: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fname = $row['fname'];
    } else {
        echo "No matching record found for id: $id";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png">
    <link rel="stylesheet" href="css/view.css">
    <title><?php echo $fname; ?></title>
</head>
<body>

<?php
include_once 'user_sidebar.php';
?>

 <div class="main--content">
      <div class="header--wrapper">
        <div class="header--title">
          <h4 style=" font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;"><?php echo $fname; ?></h4>
</div>
<p style="font-size: 12px; position: absolute; right: 30px; top: 50px;">Date Created : <?php echo date('F j, Y', strtotime($row['cdate'])); ?></p>
  </div>
      <br><br>
  <div class="row">
      <div class="col">
      <fieldset disabled>
    <label>Employee's ID</label>
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['empid']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
      </fieldset>
      </div>
      
  
      <div class="col">
      <fieldset disabled>
    <label >Contact</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['contact']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>
</div>

      <div class="row">
      <div class="col">
      <fieldset disabled>
    <label>Birthdate</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo date('F j, Y', strtotime($row['bdate'])); ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>

      <div class="col">
      <fieldset disabled>
    <label>Department</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['dept']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
     </div>

</div>

      <div class="row">
      <div class="col">
      <fieldset disabled>
    <label>Marital Status</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['mstats']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>

      <div class="col">
      <fieldset disabled>
    <label>Gender</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['gender']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>
</div>

      <div class="row">
      <div class="col">
      <fieldset disabled>
    <label>Address</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['addrss']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>
      
      <div class="col">
      <fieldset disabled>
    <label>Email</label>
    <div class="mb-3">
      <input type="text" id="disabledTextInput" class="form-control" value="<?php echo $row['email']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins';">
    </div>
      </fieldset>
      </div>
</div>

<h5>Educational Background :</h5>
     
        <div class="row">
        <div class="col">
        <fieldset disabled>
        <div class="mb-3">
        <label>Last School Attended</label>
        <input type="text" class="form-control" id="scl" name="scl" value="<?php echo $row['scl']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins'; background: #fff;">
          </div>
        </fieldset>
      </div>
    
    <div class="col">
    <fieldset disabled>
    <div class="mb-3">
        <label>Degree</label>
        <input type="text" class="form-control" id="deg" name="deg"  value="<?php echo $row['deg']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins'; background: #fff;">
</div>
      </fieldset>
    </div>
        </div>

     
        <div class="row">
        <div class="col">
        <fieldset disabled>
        <div class="mb-3">
        <label>Skills :</label>
        <input type="text" class="form-control" id="skills" name="skills"  value="<?php echo $row['skills']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins'; background: #fff;">
</div>
      </fieldset>
      </div>

     
      <div class="col">
      <fieldset disabled>
      <div class="mb-3">
        <label>Credentials :</label>
        <input type="text" class="form-control" id="cred" name="cred"  value="<?php echo $row['cred']; ?>" placeholder="no data." style="font-size: 12px; font-family: 'Poppins'; background: #fff;">
      </div>
</fieldset>   
    </div>
</div>

</body>
</html>