<?php
session_start();

if(isset($_GET['cancel'])){
    $id = $_GET['cancel'];
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            die("Error executing action_made statement: " . $stmt->error);
        }
        $stmt->close();
    }

    if(isset($_GET['empid'])) {
        $empid = $_GET['empid'];
    } else {
        die("Employee ID not provided.");
    }

    $connect_db = new mysqli('localhost','root','','emp_db');
    if ($connect_db->connect_error) {
        die("Connection failed: " . $connect_db->connect_error);
    }

    function cancelLeave($conn, $id, $empid, $user_id) {
        $query = "UPDATE leave_notice SET apprv='CANCELED' WHERE id='$id'";
       
        $result = $conn->query($query);

        if($result){
            action_made($conn, $user_id, "Canceled their Leave");
            echo "<script>window.location = 'user_leaver.php?empid=$empid'</script>";
        } else {
            die(mysqli_error($conn));
        }
    }

    cancelLeave($connect_db, $id, $empid, $user_id);
}
?>
