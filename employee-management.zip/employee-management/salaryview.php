<?php 
include 'dbconnection.php';

if(isset($_GET["empid"])){
    $id = $_GET['empid'];

    $sql = "SELECT * FROM `register` WHERE `empid` = ? ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fname = $row['fname'];
        $empid = $row['empid'];
    } else {
        echo "No matching record found for id: $id";
    }

    $stmt->close();

    $sql_salary = "SELECT * FROM `salary` WHERE `empid` = ? ORDER BY id DESC";
    $stmt_salary = $conn->prepare($sql_salary);
    $stmt_salary->bind_param("i", $id);
    $stmt_salary->execute();
    $result_salary = $stmt_salary->get_result();
    $stmt_salary->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png"> 
    <link rel="stylesheet" href="css/view.css">
    <title><?php echo $fname; ?>'s Salaries</title>

</head>
<body>

<?php
include_once 'admin_sidebar.php';
?>
<div class="main--content">
    <div class="header--wrapper">
        <div class="header--title">
            <h4 style=" font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;"><?php echo isset($fname) ? $fname."'s Salaries" : ""; ?></h4>
        </div>
    </div>
<br><br>
<!---------------------------------------ADD NOTIF----------------------------------->
  <div class="row">
    <div class="col">
    <?php
    if(isset($_SESSION['status'])){
?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4><?php echo $_SESSION['status']; ?></h4>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['status']);
    }
?>
<!--------------------------------------------------------------------------------->
<div class="table-responsive">
    <table class="table" id="tbl">
        <br>
        <thead>
            <tr>
                <th>Salary</th>
                <th>Deductive Reason</th>
                <th>Total Deduction</th>
                <th>Total Salary</th>
                <th>Date Created</th>
                <th>Last Updated</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if(isset($result_salary) && $result_salary->num_rows > 0) {
                while ($rows = $result_salary->fetch_assoc()) {
            ?>
            <tr>
                <td>₱<?php echo number_format($rows['salary'], 2); ?></td>
                <td>
                    <?php if ($rows['ph']): ?>
                        Philhealth<br>
                    <?php endif; ?>
                    <?php if ($rows['dss']): ?>
                        SSS<br>
                    <?php endif; ?>
                    <?php if ($rows['pagibig']): ?>
                        Pagibig<br>
                    <?php endif; ?>
                    <?php if ($rows['tax']): ?>
                        Tax<br>
                    <?php endif; ?>
                    <?php if (!$rows['ph'] && !$rows['dss'] && !$rows['pagibig'] && !$rows['tax']): ?>
                        no data.<br>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="printable-content">
                        <?php if ($rows['ph']): ?>
                            ₱<?php echo number_format($rows['ph']); ?><br>
                        <?php endif; ?>
                        <?php if ($rows['dss']): ?>
                            ₱<?php echo number_format($rows['dss']); ?><br>
                        <?php endif; ?>
                        <?php if ($rows['pagibig']): ?>
                            ₱<?php echo number_format($rows['pagibig']); ?><br>
                        <?php endif; ?>
                        <?php if ($rows['tax']): ?>
                            ₱<?php echo number_format($rows['tax']); ?><br>
                        <?php endif; ?>
                        <?php if ($rows['ph'] || $rows['dss'] || $rows['pagibig'] || $rows['tax'] || $rows['deduct']): ?>
                            <hr style="border: 2px solid; color: #000; border-radius: 5px;">
                        <?php endif; ?>
                        <?php if ($rows['deduct']): ?>
                            Total Deduction : ₱<?php echo number_format($rows['deduct']); ?><br>
                        <?php endif; ?>
                        <?php if (!$rows['ph'] && !$rows['dss'] && !$rows['pagibig'] && !$rows['tax'] && !$rows['deduct']): ?>
                            no data.<br>
                        <?php endif; ?>
                    </div>
                </td>
                <td>₱<?php echo number_format($rows['tsalary'], 2); ?></td>
                <td><?php echo $rows['datee']; ?></td>
                <td><?php echo $rows['udatee']; ?></td>
                <td>
                    <a href="salary_slip.php?id=<?php echo $rows['id']; ?>" class='btn btn-primary btn-sm' id="btn">VIEW</a>
                    <a href="salary_del.php" class='btn btn-danger btn-sm' id="btn" onclick="confirmDelete(event, <?php echo $rows['id']; ?>, '<?php echo $rows['fname']; ?>');">DELETE</a>
                </td>
            </tr>
            <?php 
                }
            } else {    
            ?>
            <tr>
                <td colspan="7">No salary records found for this employee.</td>
            </tr>
            <?php 
            }
            ?>
        </tbody>
    </table>
</div>
    <div class="col-lg-2">
        <a class="btn btn-primary" id="back" href="salary.php">BACK</a>
    </div>
</div>

<!-------------------------------------JS/DELETE-------------------------------------------->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmDelete(event, id, name) {
        event.preventDefault();
        Swal.fire({
            title: 'Delete ' + name + '\'s Salary?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Delete',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                deleteSalary(id, name);
            } else {
                Swal.fire({
                    title: 'Deletion operation was cancelled.',
                    icon: 'info',
                    confirmButtonText: 'OK'
                });
            }
        });
    }

    function deleteSalary(id, name) {
        fetch('salary_del.php?deleteid=' + id)
            .then(response => response.text())
            .then(data => {
                Swal.fire({
                    title: 'Successfully Deleted ' + name + '\'s Salary',
                    text: data,
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(() => {
                    location.reload(); 
                });
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'Error',
                    text: 'An error occurred while deleting the salary.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            });
    }
</script>
<!------------------------------------------------------------------------------------>

</body>
</html>
