<?php
include 'dbconnection.php';

function action_made($conn, $user_id, $action_made, $user_status) {
    $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made, user_status) VALUES (?, NOW(), ?, ?)");
    $stmt->bind_param("iss", $user_id, $action_made, $user_status);
    if (!$stmt->execute()) {
        echo "Error executing action_made statement: " . $stmt->error;
    }
    $stmt->close();
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $pass = $_POST["pass"];

    $stmt = $conn->prepare("SELECT * FROM register WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if ($pass == $row["pass"]) {
            $user_id = $row['id'];
            $usertype = $row["usertype"];
            $archived = $row["archived"];

            action_made($conn, $user_id, "Has logged in to the system", "Online");

            $register_query = "UPDATE register SET user_status='Online' WHERE id=?";
            $register_stmt = $conn->prepare($register_query);
            $register_stmt->bind_param("i", $user_id);
            if (!$register_stmt->execute()) {
                echo "Error updating user status: " . $register_stmt->error;
            }
            $register_stmt->close();

            $latest_log_query = "SELECT MAX(timelog) as latest_date FROM logs WHERE user_id=?";
            $latest_log_stmt = $conn->prepare($latest_log_query);
            $latest_log_stmt->bind_param("i", $user_id);
            $latest_log_stmt->execute();
            $latest_log_result = $latest_log_stmt->get_result();
            if ($latest_log_result && $latest_log_result->num_rows > 0) {
                $latest_log_row = $latest_log_result->fetch_assoc();
                $latest_date = $latest_log_row['latest_date'];

                $logs_query = "UPDATE logs SET user_status='Online' WHERE user_id=? AND timelog=?";
                $logs_stmt = $conn->prepare($logs_query);
                $logs_stmt->bind_param("is", $user_id, $latest_date);
                if (!$logs_stmt->execute()) {
                    echo "Error updating logs user status: " . $logs_stmt->error;
                }
                $logs_stmt->close();
            }
            $latest_log_stmt->close();

            session_start();
            $_SESSION["email"] = $email;
            $_SESSION["user_id"] = $user_id;

            if ($usertype == "ADMIN") {
                header("Location: admin.php");
                exit();
            } else if ($usertype == "USER" && $archived == "On Duty") {
                header("Location: userdash.php?empid=" . $row['empid'] . "&id=" . $row['id']);
                exit();
            } else {
                $_SESSION['invalid1'] = "Can't Login! Your account cannot be accessed at this time.";
                header("Location: login.php");
                exit();
            }
        } else {
            session_start();
            $_SESSION['invalid'] = "INVALID EMAIL OR PASSWORD!";
            header("Location: login.php");
            exit();
        }
    } else {
        session_start();
        $_SESSION['invalid'] = "INVALID EMAIL OR PASSWORD!";
        header("Location: login.php");
        exit();
    }
    $stmt->close();
}
?>
