<?php 
include 'dbconnection.php';
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,
      initial-scale=1.0"/>
      <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="css/reg.css">
      <link rel="icon" href="image/e3.png"> 
      <title>Registration</title>
    </head>
  <body>
      <form action="registration.php" method="POST" enctype="multipart/form-data" id="registerForm" onsubmit="registerForm()">
      <div>
      <h1>REGISTER</h1>
      
      <h4>Information :</h4>
      <div class="row">
  <div class="col">
    <label>Employee's Fullname</label>
    <input type="text" class="form-control" id="fname" name="fname" placeholder="Enter Full Name" required="required" style="font-size: 12px; font-family: 'Poppins';">
  </div>

  <div class="col">
            <label>Employee's ID</label>
            <input type="number" class="form-control" id="empid" name="empid" placeholder="Enter ID Number" required="required" style="font-size: 12px; font-family: 'Poppins';">
          </div>
      </div>

      <div class="row">
      <div class="col">
            <label>Birthdate</label>
            <input type="date" class="form-control" id="bdate" name="bdate" placeholder="Enter Address" required="required" style="font-size: 12px; font-family: 'Poppins';">
          </div>

  <div class="col">
    <label>Department</label>
    <select class="form-control" id="dept" name="dept" onchange="showSub(this.value)" required="required" style="font-size: 12px; font-family: 'Poppins';">
       <option style="display: none;">Select Department</option>
       <?php
       include 'dbconnection.php';
       $query=mysqli_query($conn,"select * from department");
       $sn=1;
      while($res=mysqli_fetch_array($query)){ ?>
      <option VALUE="<?php echo htmlentities($res['dfull']);?>"><?php echo htmlentities($res['dfull'])?></option>
                        
                    <?php } ?>
                    </option>
            </select>
  </div>
      </div>

      <div class="row">
          <div class="col">
            <label>Contact</label>
            <input type="number" class="form-control" id="contact" name="contact" placeholder="Enter Phone Number" required="required" style="font-size: 12px; font-family: 'Poppins';">
          </div>

          <div class="col">
    <label>Marital Status</label>
    <select class="form-control" id="mstats" name="mstats" required="required" style="font-size: 12px; font-family: 'Poppins';">
        <option value="" style="display: none;">Marital Status</option>
        <option value="Single">Single</option>
        <option value="Married">Married</option>
        <option value="Widowed">Widowed</option>
        <option value="Separated">Separated</option>
    </select>
</div> 
        </div>

      <div class="row">
          <div class="col">
            <label>Gender</label>
            <select class="form-control" id="gender" name="gender" required="required" style="font-size: 12px; font-family: 'Poppins';">
              <option style="display: none;">Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
        </div> 

          <div class="col">
            <label>Address</label>
            <input type="text" class="form-control" id="addrss" name="addrss" placeholder="Enter Address" required="required" style="font-size: 12px; font-family: 'Poppins';">
          </div>
      </div>
      </div>

          <div class="row">
            <div class="col">
            <label>Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" required="required" style="font-size: 12px; font-family: 'Poppins';">
          </div>

            <div class="col">
            <label>Password</label>
            <input type="password" class="form-control" id="pass" name="pass" placeholder="Enter Password" required="required" style="font-size: 12px; font-family: 'Poppins';">
          </div>
      </div>
<br>
      <h4>Educational Background :</h4>

          <div class="row">
        <div class="col">
        <label>Last School Attended</label>
        <input type="text" class="form-control" id="scl" name="scl" placeholder="Your Last School Attended(Complete)" required="required" style="font-size: 12px; font-family: 'Poppins';">
      </div>
    
    <div class="col">
        <label>Degree</label>
        <input type="text" class="form-control" id="deg" name="deg" placeholder="Enter your Degree" required="required" style="font-size: 12px; font-family: 'Poppins';">
    </div>
        </div>


        <div class="row">
        <div class="col">
        <label>Skills :</label>
        <input type="text" class="form-control" id="skills" name="skills" placeholder="Enter your Skills" required="required" style="font-size: 12px; font-family: 'Poppins';">
      </div>

      <div class="col">
        <label>Credentials :</label>
        <input type="text" class="form-control" id="cred" name="cred" placeholder="Enter your Credentials" required="required" style="font-size: 12px; font-family: 'Poppins';"> 
      </div>
        </div>

</div>
<br>
<div class="form-group">
    <div class="row">
        <div class="col">
            <label>Creation Date</label>
            <input class="form-control" value="<?php echo date('F j, Y');?>" readonly="readonly" name="cdate" style="font-size: 12px; font-family: 'Poppins';">
        </div>

    <div class="col">
            <label for="img">Please upload a new JPG or PNG file:</label><br>
            <div id="file-upload-container">
                <button type="button" class="btn-secondary">
                    <i class="fa fa-upload"></i> Upload
                    <input type="file" id="img" name="img" style="font-size: 12px; font-family: 'Poppins';" onchange="updateFileName()">
                    <span id="file-name"></span>
                </button>
            </div>
        </div>
</div>
</div>
          
          <div class="row">
            <div class="col">
              <br>
          <input type="submit" id="register" class="form-control" name="submit" value="Register" style="font-size: 12px; font-family: 'Poppins';">
            </div>
          </div>
<br>
          <div class="row">
              <div class="col-lg-2">
                
            <a class="btn btn-primary form-control" id="register" href="login.php" style="font-size: 12px; font-family: 'Poppins';">back</a>
            </div>
                      </div>
      </form>

<script>
    function updateFileName() {
        var fileName = document.getElementById("img").files[0].name;
        document.getElementById("file-name").textContent = fileName;
    }
</script>


  </body>
</html>