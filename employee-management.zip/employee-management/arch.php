<?php
if (isset($_GET['archiveid'])) {
    $id = $_GET['archiveid'];

    $connect_db = new mysqli('localhost', 'root', '', 'emp_db');

    if ($connect_db->connect_error) {
        die("Connection failed: " . $connect_db->connect_error);
    }

    date_default_timezone_set('Asia/Manila');

    $archive_date = date("F j, Y") . " at " . date("g:i a") . "<br>" . date("l");

    $user_id = 1;

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            echo "Error executing action_made statement: " . $stmt->error;
        }
        $stmt->close();
    }

    function fetchEmployeeName($conn, $id) {
        $stmt = $conn->prepare("SELECT fname FROM register WHERE empid=?");
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $stmt->bind_result($fname);
        $stmt->fetch();
        $stmt->close();
        return $fname;
    }

    function archiveEmployee($conn, $archive_date, $id, $user_id) {

        $fname = fetchEmployeeName($conn, $id);
        
        if (empty($fname)) {
            die("Employee not found.");
        }

        $register_query = $conn->prepare("UPDATE register SET archived='INACTIVE', archive_date=? WHERE empid=?");
        $salary_query = $conn->prepare("UPDATE salary SET archived='INACTIVE', archive_date=? WHERE empid=?");
        $leave_query = $conn->prepare("UPDATE leave_notice SET archived='INACTIVE', archive_date=? WHERE empid=?");

        $register_query->bind_param("ss", $archive_date, $id);
        $salary_query->bind_param("ss", $archive_date, $id);
        $leave_query->bind_param("ss", $archive_date, $id);

        $register_result = $register_query->execute();
        $salary_result = $salary_query->execute();
        $leave_result = $leave_query->execute();
        $register_query->close();
        $salary_query->close();
        $leave_query->close();

        if ($register_result && $salary_result && $leave_result) {
            action_made($conn, $user_id, "Archived $fname");
            echo "Employee archived successfully.";
        } else {
            die("Error archiving employee: " . $conn->error);
        }
    }

    archiveEmployee($connect_db, $archive_date, $id, $user_id);

    $connect_db->close();
}
?>
