<?php
include 'dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['fname'];
    $empid = $_POST['empid'];
    $salary = str_replace(',', '', $_POST['salary']);
    $dss = isset($_POST['dss']) ? (float) str_replace(',', '', $_POST['dss']) : 0;
    $ph = isset($_POST['ph']) ? (float) str_replace(',', '', $_POST['ph']) : 0;
    $pagibig = isset($_POST['pagibig']) ? (float) str_replace(',', '', $_POST['pagibig']) : 0;
    $tax = isset($_POST['tax']) ? (float) str_replace(',', '', $_POST['tax']) : 0;
    $deduct = isset($_POST['deduct']) ? array_sum(array_map(function ($value) {
        return (float) str_replace(',', '', $value);
    }, $_POST['deduct'])) : 0;
    $datee = $_POST['datee'];
    $useer = "On Duty";

    $totalDeduction = array_sum([$dss, $ph, $pagibig, $tax]);
    $tsalary = $salary - $totalDeduction;

    $stmt = $conn->prepare("INSERT INTO `salary` (fname, empid, salary, dss, ph, pagibig, tax, deduct, datee, tsalary, archived) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssss", $fname, $empid, $salary, $dss, $ph, $pagibig, $tax, $totalDeduction, $datee, $tsalary, $useer);

    $result = $stmt->execute();

    $user_id = 1;

    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            echo "Error executing action_made statement: " . $stmt->error;
        }
        $stmt->close();
    }

    function fetchEmployeeName($conn, $empid) {
        $stmt = $conn->prepare("SELECT fname FROM register WHERE empid=?");
        $stmt->bind_param("s", $empid);
        $stmt->execute();
        $stmt->bind_result($fname);
        $stmt->fetch();
        $stmt->close();
        return $fname;
    }

    function addSalary($conn, $fname, $empid, $salary, $dss, $ph, $pagibig, $tax, $totalDeduction, $datee, $tsalary, $useer, $result, $user_id){
        $current_fname = fetchEmployeeName($conn, $empid);
        
        if (empty($current_fname)) {
            die("Employee not found.");
        }

        if ($result) {
            session_start();
            action_made($conn, $user_id, "Added $fname's Salary");
            $_SESSION['status'] = "SALARY ADDED SUCCESSFULLY!";
            header("Location: salaryview.php?empid=$empid");
            exit();
        } else {
            die(mysqli_error($conn));
        }
    }

    addSalary($conn, $fname, $empid, $salary, $dss, $ph, $pagibig, $tax, $totalDeduction, $datee, $tsalary, $useer, $result, $user_id);
}
?>
