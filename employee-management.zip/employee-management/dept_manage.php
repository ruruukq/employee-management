<?php

include_once 'dbconnection.php';

$page_no = isset($_GET['page_no']) && $_GET['page_no'] !== "" ? (int)$_GET['page_no'] : 1;
$total_records_per_page = 10;
$offset = ($page_no - 1) * $total_records_per_page;

$sql = "SELECT * FROM `department` WHERE `id` IS NOT NULL AND `id` <> '' ORDER BY dfull ASC LIMIT $offset, $total_records_per_page";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Error: " . mysqli_error($conn));
}

$total_records_query = "SELECT COUNT(*) as total_records FROM `department` WHERE `id` IS NOT NULL AND `id` <> ''";
$total_records_result = mysqli_query($conn, $total_records_query);
$total_records = mysqli_fetch_assoc($total_records_result)['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png">
    <link rel="stylesheet" href="css/view.css">
    <title>ADMIN - EMPLOYEE DEPARTMENTS</title>
    <style>
        .table-responsive {
            overflow-x: auto;
        }
th:nth-child(1),
td:nth-child(1) {
    width: 600px;
}

    </style>
</head>
<body> 

<?php
include_once 'admin_sidebar.php';
?>
<div class="main--content">
    <div class="header--wrapper">
        <div class="header--title">
            <h4 style="font-family: 'verdana'; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;">&nbsp;&nbsp;LIST OF DEPARTMENT</h4>
            </div>
        </div>
            <div class="row">
                <div class="col"></div>
                <div class="col"></div>
                <div class="col"></div>
                <div class="col"></div>
                
            <div class="col-lg-1">
              <button type="button" class="btn btn-primary" data-bs-toggle="modal" id="back" data-bs-target="#addModal" style="position: absolute; right: 30px; top: 30px;">
 ADD
</button>
</div>
    </div>

<!----------------------ADD-------------------------->
    <form action="dept.php" method="POST">
    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background: #137d74; color: #fff;">
        <h1 class="modal-title fs-5" id="addModalLabel">ADD DEPARTMENT</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
            <label>ADD DEPARTMENT</label>
            <input type="text" class="form-control" id="dfull" name="dfull" required>
        </div>
        <div class="mb-3">
            <label>Creation Date</label>
            <input type="text" class="form-control" id="cdate" name="cdate" value="<?php echo date('F j, Y');?>" readonly>
        </div>

      </div>
      <div class="modal-footer">
        <button id="update" type="submit" name="submit" class="btn btn-lg">Add</button>
      </div>
    </div>
  </div>
</div>

<!--------------------------------ADD BUTTON AND NOTIFICATIONS---------------->
    <div class="row">
    <div class="col">
    <?php
    if(isset($_SESSION['status'])){
?>
<div class="alert alert-success alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4><?php echo $_SESSION['status']; ?></h4>
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['status']);
    }
?>
<!----------------------------------------------------------------------------->
<!-----------------------------EXIST DEPARTMENT------------------------------------------>
<?php
    if(isset($_SESSION['estatus'])){
?>
    <div class="alert alert-danger alert-dismissible fade show position-fixed top-40 start-50  translate-middle-x" role="alert" style="z-index: 10000;">
<h4 class="alert-heading"><?php echo $_SESSION['estatus']; ?></h4>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php
    unset($_SESSION['estatus']);
    }
?>
</div>
<!----------------------------------------------------------------------------------------->
    
    </form>
                
<br><br>
<!---------------------------------------------------->

<!----------------------EDIT--------------------------->

<div class="modal fade" id="eModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background: #137d74; color: #fff;">
        <h1 class="modal-title fs-5" id="exampleModalLabel">EDIT DEPARTMENT</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="deptedit.php" method="POST">

      <div class="modal-body">
      <input type="hidden" name="id" value="<?php echo $id; ?>">
    <div class="mb-3">
        <label>EDIT DEPARTMENT</label>
        <input type="hidden" name="id" id="id">
<input type="text" class="form-control" id="dfull" name="dfull" required>

    </div>

    <div class="mb-3">
        <label>Last Updated</label>
        <input type="text" class="form-control" id="cdate" name="edate" value="<?php echo date('F j, Y');?>" readonly>
    </div>

      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-lg" id="back">Edit</button>
      </div>
    </div>
    </form>
  </div>
</div>

<!----------------------------------------------------->

<!---------------------TABLE--------------------------->
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>DEPARTMENT</th>
                <th>Date Created</th>
                <th>Last Updated</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($result as $rows): ?>
                <tr>
                    <td><?php echo $rows['dfull']; ?></td>
                    <td><?php echo $rows['cdate']; ?></td>
                    <td><?php echo $rows['edate']; ?></td>
                    <td >
                    <button type="button" class="btn" id="back" data-bs-toggle="modal" data-bs-target="#eModal" data-id="<?php echo $rows['id']; ?>" data-dfull="<?php echo $rows['dfull']; ?>">EDIT</button>
                    <a href="dept_delete.php?deleteid=<?php echo $rows['id']; ?>" class='btn btn-danger btn-sm' id="btn" onclick="confirmDelete(event, <?php echo $rows['id']; ?>, '<?php echo $rows['dfull']; ?>');">DELETE</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

<!---------------------------------------------------->

<!-----------------------PAGINATION-------------------------------->
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item <?php echo $page_no <= 1 ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page_no=<?php echo $page_no - 1; ?>">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $total_no_of_pages; $i++) : ?>
                    <li class="page-item <?php echo $page_no == $i ? 'active' : ''; ?>">
                        <a class="page-link" href="?page_no=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?php echo $page_no >= $total_no_of_pages ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page_no=<?php echo $page_no + 1; ?>">Next</a>
                </li>
            </ul>
                </nav>
                
    </div>
</div>
<!----------------------------------------------------------------->

<!---------------------------DELETE/JS----------------------------->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
 function confirmDelete(event, id, dept) {
    event.preventDefault();
    Swal.fire({
        title: 'Delete ' + dept + '?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#135D66',
        confirmButtonText: 'Delete',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            deleteDept(id, dept);
        } else {
            Swal.fire({
                title: 'Cancelled',
                icon: 'info',
                confirmButtonColor: '#135D66',
                confirmButtonText: 'OK'
            });
        }
    });
}

function deleteDept(id, dept) {
    fetch('dept_delete.php?deleteid=' + id)
        .then(response => {
            if (response.ok) {
                return response.text();
            } else {
                throw new Error('Network response was not ok');
            }
        })
        .then(data => {
            Swal.fire({
                title: 'Successfully Deleted ' + dept,
                icon: 'success',
                confirmButtonColor: '#135D66',
                confirmButtonText: 'OK'
            });
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({
                title: 'Error',
                text: 'An error occurred while deleting the department.',
                icon: 'error',
                confirmButtonColor: '#135D66',
                confirmButtonText: 'OK'
            });
        });
}
</script>
<!------------------------------------------------------------------>

<script>
    $(document).ready(function() {
        $('#eModal').on('show.bs.modal', function(event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var dfull = button.data('dfull');
            var modal = $(this);
            modal.find('.modal-body #id').val(id);
            modal.find('.modal-body #dfull').val(dfull);
        });
    });
</script>


</body>
</html>
