<?php 
include 'dbconnection.php';

$rows = [];


    $sql = "SELECT u.fname, u.usertype,
            DATE_FORMAT(l.timelog, '%M %d, %Y at %l:%i %p') as formatted_date, 
            l.action_made 
            FROM logs l 
            INNER JOIN register u ON l.user_id = u.id
            WHERE u.usertype = 'ADMIN'
            ORDER BY l.timelog ASC";

    $result = $conn->query($sql);

    if (!$result) {
        die("Error executing the query: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
    } else {
        echo "No matching record found for id: $id";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <link rel="icon" href="image/e3.png">
    <link rel="stylesheet" href="css/admina1.css">
    <title>Activity Logs</title>
</head>
<body>

<?php
include_once 'admin_sidebar.php';
?>

<div class='main--content'>
    <div class='header--wrapper'>
        <div class='header--title'>
            <h4 style='font-family: Verdana; color: #003b43; font-weight: bold; display: flex; position: absolute; top: 30px;'>&nbsp;ACTIVITY LOGS</h4>

            </div>
</div>

   <div class="dropdown">
    <button class="btn btn-primary btn-sm dropdown-toggle" id="back" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false" style="position: absolute; left: 5px; top: 40px;">
       ADMIN
    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <li><a class="dropdown-item" href="admin_activities.php">ADMIN</a></li>
         <li><a class="dropdown-item" href="user_activities.php">USERS</a></li>
    </ul>
    </div>
<br><br><br>

    <div class='table-container'>
        <table class='table table-bordered'>
            <tr>
                <th>Name</th>
                <th style="text-align: center;">Usertype</th>
                <th style='text-align: center;'>Activity</th>
                <th style='text-align: center;'>Date and Time</th>
            </tr>
            <?php if (!empty($rows)): ?>
                <?php foreach ($rows as $row): ?>
                    <tr style='font-size: 15px;'>
                    <td style="width: 200px;"><?php echo htmlspecialchars($row['fname']); ?></td>
                    <td style="text-align: center; width: 150px;"><?php echo htmlspecialchars($row['usertype']); ?></td>
                        <td style='text-align: center; width: 300px; font-style: italic; font-variant: oblique;'><?php echo htmlspecialchars($row['action_made']); ?></td>
                        <td style='text-align: center; width: 300px;'><?php echo htmlspecialchars($row['formatted_date']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="2" style='text-align: center;'>No records found.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>

    <div class="col-lg-2">
        <a class="btn btn-success form-control" style="font-size: 12px; font-family: 'Poppins';" id="editButton" href="admin.php">BACK</a>
    </div>
</div>

</body>
</html>
