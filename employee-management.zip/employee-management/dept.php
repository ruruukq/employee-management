<?php 
include 'dbconnection.php';
session_start(); 

if(isset($_POST['submit'])){
    $dfull = $_POST['dfull'];
    $cdate = $_POST['cdate'];
    
    $user_id = 1;
    
    function action_made($conn, $user_id, $action_made) {
        $stmt = $conn->prepare("INSERT INTO logs (user_id, timelog, action_made) VALUES (?, NOW(), ?)");
        $stmt->bind_param("is", $user_id, $action_made);
        if (!$stmt->execute()) {
            $_SESSION['error'] = "Error executing action_made statement: " . $stmt->error;
            header('Location: error.php');
            exit();
        }
        $stmt->close();
    }
    $check_sql = "SELECT * FROM department WHERE dfull = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $dfull);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if($check_result->num_rows > 0) {
        $_SESSION['estatus'] = "OOPS! DEPARTMENT ALREADY EXIST!";
        header('Location: dept_manage.php');
        exit();
    } else {
        $insert_sql = "INSERT INTO department (dfull, cdate) VALUES (?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("ss", $dfull, $cdate);
        $result = $insert_stmt->execute();
        
        if($result){
            action_made($conn, $user_id, "Added $dfull");
            $_SESSION['status'] = "DEPARTMENT ADDED SUCCESSFULLY";
            header('Location: dept_manage.php');
            exit();
        } else {
            $_SESSION['error'] = "Error inserting $dfull " . $conn->error;
            header('Location: error.php');
            exit();
        }
    }
}
?>
